import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    kotlin("jvm") version "2.0.21"
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21"
    id("org.jetbrains.compose") version "1.7.1"
}

kotlin { jvmToolchain(17) }

dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    // X.509 certificates for iPhone pairing (same as the Android app)
    implementation("org.bouncycastle:bcpkix-jdk18on:1.78.1")
    implementation("org.bouncycastle:bcprov-jdk18on:1.78.1")
    implementation("org.json:json:20240303")
}

compose.desktop {
    application {
        mainClass = "dev.fakegeo.desktop.MainKt"
        nativeDistributions {
            targetFormats(TargetFormat.Dmg, TargetFormat.Msi)
            packageName = "FakeGeo"
            packageVersion = "1.0.0"
            description = "Location changer for iPhone over USB"
            includeAllModules = true   // HTTP client, TLS/EC crypto, etc. must be inside the bundled runtime
            macOS { bundleID = "dev.fakegeo.desktop"; iconFile.set(project.file("icons/icon.icns")) }
            windows { iconFile.set(project.file("icons/icon.ico")); menu = true; shortcut = true }
        }
    }
}
