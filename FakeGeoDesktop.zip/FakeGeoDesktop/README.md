# FakeGeo Desktop (macOS first)

Same iOS engine as the Android app (pairing, CoreDevice tunnel, RSD, DTX LocationSimulation);
only the USB layer differs: the Mac's own `usbmuxd` is used (/var/run/usbmuxd).

## Build (macOS, JDK 17+, Gradle 8.7)
    gradle run            # start the app
    gradle createDistributable  # .app (CI also signs + makes the .dmg)
Or push to GitHub: .github/workflows/build-mac.yml builds the .dmg.

## First use
1. Connect iPhone, unlock, Trust.  2. "Prepare the iPhone": Pair -> Enable Developer Mode (iPhone restarts) -> Mount disk image (3 files).
3. Map: click -> Teleport. Keep the app open; Stop = real location again.

Windows: same code; needs iTunes/Apple Devices installed (usbmuxd on TCP 27015). Build with `gradle packageMsi` on Windows.

## Wi-Fi mode (macOS)
Needs the pymobiledevice3 tunnel (iOS 17+ only offers developer services through it), then the app's own RSD + RSDCheckin + DTX code over normal sockets.
One-time: `pip3 install -U pymobiledevice3`; with the cable do Pair / Developer Mode / disk image (USB Mode), then press "Turn on Wi-Fi for this iPhone"; unplug.
On Teleport macOS asks for your password ONCE per app launch. A small helper (running as root) keeps the tunnel alive, restarts it when it drops
("lockdown start-tunnel" first, then "remote start-tunnel -t wifi") and stops when the app quits.
Allow FakeGeo under System Settings > Privacy & Security > Local Network (when started with `gradle run`, allow Terminal / your IDE).

### Logs
Map screen > "Show log" (Copy log button). The same text is saved in `~/Library/Logs/FakeGeo/fakegeo.log`;
the raw tunnel output is in `~/Library/Logs/FakeGeo/wifi-tunnel.log`. Send these two files when something fails.
