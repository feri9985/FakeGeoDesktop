# FakeGeo Desktop (macOS first)

Same iOS engine as the Android app (pairing, CoreDevice tunnel, RSD, DTX LocationSimulation);
only the USB layer differs: the Mac's own `usbmuxd` is used (/var/run/usbmuxd).

## Build (macOS, JDK 17+, Gradle 8.7)
    gradle run            # start the app
    gradle packageDmg     # -> build/compose/binaries/main/dmg/FakeGeo-1.0.0.dmg
Or push to GitHub: .github/workflows/build-mac.yml builds the .dmg.

## First use
1. Connect iPhone, unlock, Trust.  2. "Prepare the iPhone": Pair -> Enable Developer Mode (iPhone restarts) -> Mount disk image (3 files).
3. Map: click -> Teleport. Keep the app open; Stop = real location again.

Windows: same code; needs iTunes/Apple Devices installed (usbmuxd on TCP 27015). Build with `gradle packageMsi` on Windows.
