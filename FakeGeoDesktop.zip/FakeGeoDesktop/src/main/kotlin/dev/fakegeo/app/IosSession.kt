package dev.fakegeo.app

/** The position the iPhone should show. */
object IosFeed {
    @Volatile var lat = Double.NaN
    @Volatile var lon = Double.NaN
    @Volatile var seq = 0L
    @Volatile var active = false

    fun set(la: Double, lo: Double) { lat = la; lon = lo; seq++ }
}

/** What the screen shows about the iPhone connection. */
object IosState {
    @Volatile var running = false
    @Volatile var status = ""
    @Volatile var updates = 0
    @Volatile var reconnects = 0
    @Volatile var lastError = ""
    @Volatile var lastReport = ""
}

/** Keeps USB -> pairing -> CoreDevice tunnel -> RSD -> DTX LocationSimulation alive and reconnects on drops. */
object IosSession {
    @Volatile private var stopFlag = false
    @Volatile private var thread: Thread? = null

    fun stopRequested() = stopFlag
    fun stop() { stopFlag = true; if (IosState.running) IosState.status = "Stopping…" }

    fun start(deviceId: Int, onEnd: () -> Unit) {
        if (thread?.isAlive == true) return
        stopFlag = false
        IosState.updates = 0; IosState.reconnects = 0; IosState.lastError = ""
        IosState.running = true
        IosState.status = "Connecting to the iPhone…"
        thread = Thread {
            var attempt = 0
            var quickFailures = 0
            try {
                while (!stopFlag) {
                    val t0 = SystemClock.elapsedRealtime()
                    IosState.status = if (attempt == 0) "Connecting to the iPhone…" else "Reconnecting to the iPhone (#$attempt)…"
                    val rep = try { IosPairing.pairAndTest(deviceId, live = true) } catch (e: Throwable) { "ERROR: $e" }
                    IosState.lastReport = rep.takeLast(8000)
                    if (stopFlag) break
                    val lived = SystemClock.elapsedRealtime() - t0
                    quickFailures = if (lived > 20_000) 0 else quickFailures + 1
                    if (quickFailures >= 5) {
                        IosState.lastError = "5 quick failures in a row"
                        val why = rep.trim().lines().lastOrNull { it.isNotBlank() }?.take(160) ?: ""
                        IosState.status = "Stopped: 5 quick failures in a row. Last message: $why\nIs the iPhone unlocked (screen on), with Developer Mode on and the disk image mounted?"
                        break
                    }
                    attempt++; IosState.reconnects = attempt
                    IosState.status = "Connection lost, retrying…"
                    var w = 0
                    while (w < 3000 && !stopFlag) { Thread.sleep(250); w += 250 }
                }
            } finally {
                IosState.running = false; IosFeed.active = false
                if (stopFlag) IosState.status = "Stopped: the iPhone is back on its real location."
                onEnd()
            }
        }.also { it.isDaemon = true; it.start() }
    }
}
