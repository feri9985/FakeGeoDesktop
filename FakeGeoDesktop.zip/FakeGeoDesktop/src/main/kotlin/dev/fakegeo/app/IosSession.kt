package dev.fakegeo.app

/** The position the iPhone should show. */
object IosFeed {
    @Volatile var lat = Double.NaN
    @Volatile var lon = Double.NaN
    @Volatile var seq = 0L
    @Volatile var active = false

    fun set(la: Double, lo: Double) { lat = la; lon = lo; seq++ }
}

/** What the screen shows about the iPhone connection. */
object IosState {
    @Volatile var running = false
    @Volatile var status = ""
        set(v) {
            field = v
            // every change goes to the log file (the 5-second position heartbeat is skipped: too noisy)
            if (v.isNotBlank() && !v.startsWith("Connected: the iPhone is at")) FileLog.add("status: " + v.replace('\n', ' '))
        }
    @Volatile var updates = 0
    @Volatile var reconnects = 0
    @Volatile var lastError = ""
    @Volatile var lastReport = ""
}

/** Keeps USB -> pairing -> CoreDevice tunnel -> RSD -> DTX LocationSimulation alive and reconnects on drops. */
object IosSession {
    @Volatile private var stopFlag = false
    @Volatile private var thread: Thread? = null

    fun stopRequested() = stopFlag
    fun stop() { stopFlag = true; if (IosState.running) IosState.status = "Stopping…" }

    fun start(deviceId: Int, wifi: Boolean = false, serial: String = "", onEnd: () -> Unit) {
        if (thread?.isAlive == true) return
        stopFlag = false
        IosState.updates = 0; IosState.reconnects = 0; IosState.lastError = ""
        IosState.running = true
        IosState.status = "Connecting to the iPhone…"
        thread = Thread {
            var attempt = 0
            var quickFailures = 0
            try {
                while (!stopFlag) {
                    val t0 = SystemClock.elapsedRealtime()
                    IosState.status = if (attempt == 0) "Connecting to the iPhone…" else "Reconnecting to the iPhone (#$attempt)…"
                    var wifiFatal = false
                    val rep = if (wifi) {
                        val o = try { WifiTunnel.run() } catch (e: Throwable) { WifiTunnel.Outcome("ERROR: $e", false) }
                        wifiFatal = o.fatal
                        o.report
                    } else try {
                        // usbmuxd gives the iPhone a NEW id every time it re-attaches (cable blip, restart): look it up again by serial
                        val id = if (serial.isNotEmpty() && !UsbMux.directHosts.containsKey(deviceId))
                            (try { UsbMux.listDevices().firstOrNull { it.serial == serial && it.connection != "Network" }?.id } catch (_: Exception) { null }) ?: deviceId
                        else deviceId
                        IosPairing.pairAndTest(id, live = true)
                    } catch (e: Throwable) { "ERROR: $e" }
                    IosState.lastReport = rep.takeLast(8000)
                    if (stopFlag) break
                    if (wifiFatal) {
                        IosState.lastError = "Wi-Fi tunnel"
                        IosState.status = rep.trim().lines().filter { it.isNotBlank() }.takeLast(3).joinToString("\n").ifBlank { "The Wi-Fi tunnel could not start." }
                        break
                    }
                    if (!wifi && UsbMux.directHosts.containsKey(deviceId) && rep.contains("Tunnel handshake error")) {
                        IosState.lastError = "Wi-Fi tunnel refused"
                        val detail = rep.lines().filter { it.contains("Tunnel handshake") || it.contains("not available") || it.contains("failed") || it.contains("closed") }.takeLast(6).joinToString("\n")
                        IosState.status = "The iPhone (iOS 17+) does not open the location tunnel over Wi-Fi in this mode. Connect the cable, go back and choose USB Mode.\n\nDETAILS (send me this):\n$detail"
                        break
                    }
                    val lived = SystemClock.elapsedRealtime() - t0
                    quickFailures = if (lived > 20_000) 0 else quickFailures + 1
                    if (quickFailures >= 5) {
                        IosState.lastError = "5 quick failures in a row"
                        val why = rep.trim().lines().lastOrNull { it.isNotBlank() }?.take(160) ?: ""
                        IosState.status = "Stopped: 5 quick failures in a row. Last message: $why\nIs the iPhone unlocked (screen on), with Developer Mode on and the disk image mounted?"
                        break
                    }
                    attempt++; IosState.reconnects = attempt
                    IosState.status = "Connection lost, retrying…"
                    var w = 0
                    while (w < 3000 && !stopFlag) { Thread.sleep(250); w += 250 }
                }
            } finally {
                IosState.running = false; IosFeed.active = false
                if (stopFlag) IosState.status = "Stopped: the iPhone is back on its real location."
                onEnd()
            }
        }.also { it.isDaemon = true; it.start() }
    }
}
