package dev.fakegeo.app

import java.util.concurrent.ConcurrentHashMap

/** The position every connected device shows (one position for all of them). */
object IosFeed {
    @Volatile var lat = Double.NaN
    @Volatile var lon = Double.NaN
    @Volatile var seq = 0L
    @Volatile var active = false

    fun set(la: Double, lo: Double) { lat = la; lon = lo; seq++ }
}

/** What the screen shows about ONE iPhone connection. */
class DevState(@Volatile var tag: String) {
    /** The session thread is running (connecting, connected or reconnecting). */
    @Volatile var running = false
    /** The location channel to the iPhone is open: the iPhone follows the position. */
    @Volatile var live = false
    @Volatile var status = ""
        set(v) {
            field = v
            // every change goes to the log file (the 5-second position heartbeat is skipped: too noisy)
            if (v.isNotBlank() && !v.startsWith("Connected: the iPhone is at")) FileLog.add("[$tag] status: " + v.replace('\n', ' '))
        }
    @Volatile var updates = 0
    @Volatile var reconnects = 0
    @Volatile var lastError = ""
    @Volatile var lastReport = ""
}

/**
 * Keeps USB (or the Wi-Fi tunnel) -> pairing -> CoreDevice tunnel -> RSD -> DTX LocationSimulation alive for ONE iPhone
 * and reconnects on drops. Several sessions can run at the same time, one thread each.
 */
class IosSession(val key: String, initialLabel: String) {
    val state = DevState(initialLabel)
    var label: String = initialLabel
        set(v) { field = v; state.tag = v }

    @Volatile var stopFlag = false
    @Volatile private var thread: Thread? = null

    fun isRunning() = thread?.isAlive == true
    fun stop() { stopFlag = true; if (state.running) state.status = "Stopping…" }

    fun start(deviceId: Int, wifi: Boolean = false, serial: String = "", useUdid: Boolean = false, onEnd: () -> Unit = {}) {
        if (thread?.isAlive == true) return
        stopFlag = false
        state.updates = 0; state.reconnects = 0; state.lastError = ""
        state.running = true; state.live = false
        state.status = "Connecting to the iPhone…"
        IosFeed.active = true
        val me = this
        thread = Thread {
            tl.set(me)
            var attempt = 0
            var quickFailures = 0
            try {
                while (!stopFlag) {
                    val t0 = SystemClock.elapsedRealtime()
                    state.status = if (attempt == 0) "Connecting to the iPhone…" else "Reconnecting to the iPhone (#$attempt)…"
                    var wifiFatal = false
                    val rep = if (wifi) {
                        val o = try { WifiTunnel.run(serial, useUdid) } catch (e: Throwable) { WifiTunnel.Outcome("ERROR: $e", false) }
                        wifiFatal = o.fatal
                        o.report
                    } else try {
                        // usbmuxd gives the iPhone a NEW id every time it re-attaches (cable blip, restart): look it up again by serial
                        val id = if (serial.isNotEmpty() && !UsbMux.directHosts.containsKey(deviceId))
                            (try { UsbMux.listDevices().firstOrNull { it.serial == serial && it.connection != "Network" }?.id } catch (_: Exception) { null }) ?: deviceId
                        else deviceId
                        IosPairing.pairAndTest(id, live = true)
                    } catch (e: Throwable) { "ERROR: $e" }
                    state.lastReport = rep.takeLast(8000)
                    if (stopFlag) break
                    if (wifiFatal) {
                        state.lastError = "Wi-Fi tunnel"
                        state.status = rep.trim().lines().filter { it.isNotBlank() }.takeLast(3).joinToString("\n").ifBlank { "The Wi-Fi tunnel could not start." }
                        break
                    }
                    if (!wifi && UsbMux.directHosts.containsKey(deviceId) && rep.contains("Tunnel handshake error")) {
                        state.lastError = "Wi-Fi tunnel refused"
                        val detail = rep.lines().filter { it.contains("Tunnel handshake") || it.contains("not available") || it.contains("failed") || it.contains("closed") }.takeLast(6).joinToString("\n")
                        state.status = "The iPhone (iOS 17+) does not open the location tunnel over Wi-Fi in this mode. Connect the cable, go back and choose USB Mode.\n\nDETAILS (send me this):\n$detail"
                        break
                    }
                    val lived = SystemClock.elapsedRealtime() - t0
                    quickFailures = if (lived > 20_000) 0 else quickFailures + 1
                    if (quickFailures >= 5) {
                        state.lastError = "5 quick failures in a row"
                        val why = rep.trim().lines().lastOrNull { it.isNotBlank() }?.take(160) ?: ""
                        state.status = "Stopped: 5 quick failures in a row. Last message: $why\nIs the iPhone unlocked (screen on), with Developer Mode on and the disk image mounted?"
                        break
                    }
                    attempt++; state.reconnects = attempt
                    state.status = "Connection lost, retrying…"
                    var w = 0
                    while (w < 3000 && !stopFlag) { Thread.sleep(250); w += 250 }
                }
            } finally {
                state.running = false; state.live = false
                if (IosSessions.runningCount() <= 1) IosFeed.active = false   // this thread still counts itself
                if (stopFlag) state.status = "Stopped: back on the real location."
                onEnd()
            }
        }.also { it.isDaemon = true; it.start() }
    }

    companion object {
        private val tl = ThreadLocal<IosSession?>()

        /** The session whose thread is calling (null on other threads, for example the setup screen). */
        fun current(): IosSession? = tl.get()

        /** Stop requested for the session of the calling thread. */
        fun stopRequested(): Boolean = tl.get()?.stopFlag ?: false

        /** "[iPhone 15 Pro] " for log lines of a session, empty otherwise. */
        fun tag(): String = tl.get()?.let { "[${it.label}] " } ?: ""
    }
}

/** All iPhone sessions of this app run (one per device). */
object IosSessions {
    private val map = ConcurrentHashMap<String, IosSession>()

    fun of(key: String, label: String): IosSession {
        val s = map.computeIfAbsent(key) { IosSession(key, label) }
        s.label = label
        return s
    }

    fun all(): List<IosSession> = map.values.toList()
    fun runningCount(): Int = map.values.count { it.isRunning() }
    fun stopAll() { map.values.forEach { it.stop() } }
}
