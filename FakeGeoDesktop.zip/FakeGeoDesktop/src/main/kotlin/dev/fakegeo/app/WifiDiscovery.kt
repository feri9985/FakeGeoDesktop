package dev.fakegeo.app

import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Finds an iPhone on the local Wi-Fi without asking usbmuxd, and lets the app talk to it directly over TCP.
 * When Wi-Fi is turned on, the iPhone's lockdownd listens on port 62078. Two ways to find it:
 *  1. scan the Mac's own IPv4 network for that open port (most reliable),
 *  2. the Bonjour name the iPhone announces (macOS tool dns-sd), which carries its IPv6 link-local address.
 */
object WifiDiscovery {
    private const val LOCKDOWN_PORT = 62078
    private val bonjourLine = Regex("""Add\s+\d+\s+(\d+)\s+\S+\s+_apple-mobdev2\._tcp\.\s+([0-9A-Fa-f:]{17})@([0-9A-Fa-f:]+)""")

    /** [log] receives the whole progress text each time it grows, so the screen can show it. */
    fun find(log: (String) -> Unit = {}): List<MuxDevice> {
        val lines = ArrayList<String>()
        fun note(s: String) { lines.add(s); log(lines.joinToString("\n")) }

        val v4 = scanV4(::note)
        if (v4.isNotEmpty()) {
            val a = v4.first()
            val id = -(1 + (a.hostAddress.hashCode() and 0x3FFFFFFF))
            UsbMux.directHosts[id] = a
            note("Found an iPhone at ${a.hostAddress}")
            return listOf(MuxDevice(id, a.hostAddress ?: "", "Network", 0))
        }
        return bonjour(::note)
    }

    // ------------------------------------------------------------------ 1. scan the local IPv4 network

    private fun scanV4(note: (String) -> Unit): List<InetAddress> {
        val prefixes = LinkedHashSet<String>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces().toList()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) {
                    val a = ia.address
                    if (a is Inet4Address && a.isSiteLocalAddress) prefixes.add(a.hostAddress.substringBeforeLast('.'))
                }
            }
        } catch (e: Exception) { note("Network list failed: ${e.message}") }
        if (prefixes.isEmpty()) { note("This Mac has no Wi-Fi/LAN address (IPv4)."); return emptyList() }

        val hits = CopyOnWriteArrayList<InetAddress>()
        val pool = Executors.newFixedThreadPool(64)
        for (p in prefixes) for (i in 1..254) pool.execute {
            try {
                val a = InetAddress.getByName("$p.$i")
                Socket().use { it.connect(InetSocketAddress(a, LOCKDOWN_PORT), 700) }
                hits.add(a)
            } catch (_: Exception) {}
        }
        pool.shutdown()
        pool.awaitTermination(20, TimeUnit.SECONDS)
        note("Scanned ${prefixes.joinToString { "$it.x" }}: ${hits.size} device(s) with port $LOCKDOWN_PORT open")
        return hits
    }

    // ------------------------------------------------------------------ 2. Bonjour name (IPv6 link-local)

    private fun bonjour(note: (String) -> Unit): List<MuxDevice> {
        if (!System.getProperty("os.name").lowercase().contains("mac")) return emptyList()
        val found = CopyOnWriteArrayList<Triple<Int, String, String>>()
        val proc = try {
            ProcessBuilder("/usr/bin/dns-sd", "-B", "_apple-mobdev2._tcp", "local").redirectErrorStream(true).start()
        } catch (e: Exception) { note("Bonjour tool failed: ${e.message}"); return emptyList() }
        val reader = Thread {
            try {
                proc.inputStream.bufferedReader().forEachLine { l ->
                    bonjourLine.find(l)?.let { m -> found.add(Triple(m.groupValues[1].toInt(), m.groupValues[2], m.groupValues[3])) }
                }
            } catch (_: Exception) {}
        }
        reader.isDaemon = true
        reader.start()
        Thread.sleep(3000)
        proc.destroy()
        reader.join(500)
        note("Bonjour: ${found.size} announcement(s) from iPhones")

        val result = ArrayList<MuxDevice>()
        val done = HashSet<String>()
        for ((idx, mac, v6) in found) {
            if (mac in done) continue
            val addr: InetAddress = (try {
                val raw = InetAddress.getByName(v6).address
                val nif = NetworkInterface.getByIndex(idx)
                if (nif != null) Inet6Address.getByAddress(null, raw, nif) else null
            } catch (_: Exception) { null }) ?: continue
            val ok = try {
                Socket().use { it.connect(InetSocketAddress(addr, LOCKDOWN_PORT), 2500) }
                true
            } catch (e: Exception) { note("Bonjour address on interface $idx did not answer: ${e.message}"); false }
            if (!ok) continue
            done.add(mac)
            val id = -(1 + (mac.hashCode() and 0x3FFFFFFF))
            UsbMux.directHosts[id] = addr
            note("Found an iPhone through Bonjour (interface $idx)")
            result.add(MuxDevice(id, mac, "Network", 0))
            break
        }
        return result
    }
}
