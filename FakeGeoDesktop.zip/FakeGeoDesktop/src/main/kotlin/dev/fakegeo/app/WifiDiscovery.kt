package dev.fakegeo.app

import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket

/**
 * Finds an iPhone on the local Wi-Fi with macOS's own Bonjour tool (dns-sd), without asking usbmuxd.
 * The iPhone is then reached directly over TCP (lockdownd listens on port 62078 when Wi-Fi is turned on).
 */
object WifiDiscovery {
    private const val LOCKDOWN_PORT = 62078
    private val line = Regex("""Add\s+\d+\s+(\d+)\s+\S+\s+_apple-mobdev2\._tcp\.\s+([0-9A-Fa-f:]{17})@([0-9A-Fa-f:]+)""")

    fun find(log: (String) -> Unit = {}): List<MuxDevice> {
        if (!System.getProperty("os.name").lowercase().contains("mac")) return emptyList()
        val found = java.util.concurrent.CopyOnWriteArrayList<Triple<Int, String, String>>()
        val proc = try {
            ProcessBuilder("/usr/bin/dns-sd", "-B", "_apple-mobdev2._tcp", "local").redirectErrorStream(true).start()
        } catch (e: Exception) { log("dns-sd failed: ${e.message}"); return emptyList() }
        val reader = Thread {
            try {
                proc.inputStream.bufferedReader().forEachLine { l ->
                    line.find(l)?.let { m -> found.add(Triple(m.groupValues[1].toInt(), m.groupValues[2], m.groupValues[3])) }
                }
            } catch (_: Exception) {}
        }
        reader.isDaemon = true
        reader.start()
        Thread.sleep(3000)
        proc.destroy()
        reader.join(500)

        val result = ArrayList<MuxDevice>()
        val done = HashSet<String>()
        for ((idx, mac, v6) in found) {
            if (mac in done) continue
            val addr: InetAddress = (try {
                val raw = InetAddress.getByName(v6).address
                val nif = NetworkInterface.getByIndex(idx)
                if (nif != null) Inet6Address.getByAddress(null, raw, nif) else null
            } catch (_: Exception) { null }) ?: continue
            val ok = try {
                Socket().use { it.connect(InetSocketAddress(addr, LOCKDOWN_PORT), 2500) }
                true
            } catch (e: Exception) { log("Wi-Fi: $mac not reachable: ${e.message}"); false }
            if (!ok) continue
            done.add(mac)
            val id = -(1 + (mac.hashCode() and 0x3FFFFFFF))
            UsbMux.directHosts[id] = addr
            result.add(MuxDevice(id, mac, "Network", 0))
        }
        return result
    }
}
