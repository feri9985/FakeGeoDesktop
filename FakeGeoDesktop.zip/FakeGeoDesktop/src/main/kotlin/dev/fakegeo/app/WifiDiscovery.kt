package dev.fakegeo.app

import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Finds an iPhone on the local Wi-Fi without asking usbmuxd, and lets the app talk to it directly over TCP.
 * When Wi-Fi is turned on, the iPhone's lockdownd listens on port 62078. Two ways to find it:
 *  1. scan the Mac's own IPv4 network for that open port (most reliable),
 *  2. the Bonjour name the iPhone announces (macOS tool dns-sd), which carries its IPv6 link-local address.
 */
object WifiDiscovery {
    private const val LOCKDOWN_PORT = 62078
    private val bonjourLine = Regex("""Add\s+\d+\s+(\d+)\s+\S+\s+_apple-mobdev2\._tcp\.\s+([0-9A-Fa-f:]{17})@([0-9A-Fa-f:]+)""")

    /** [log] receives the whole progress text each time it grows, so the screen can show it. */
    fun find(log: (String) -> Unit = {}): List<MuxDevice> {
        val lines = ArrayList<String>()
        fun note(s: String) { lines.add(s); log(lines.joinToString("\n")) }

        val v4 = scanV4(::note)
        if (v4.isNotEmpty()) {
            val a = v4.first()
            val id = -(1 + (a.hostAddress.hashCode() and 0x3FFFFFFF))
            UsbMux.directHosts[id] = a
            note("Found an iPhone at ${a.hostAddress}")
            return listOf(MuxDevice(id, a.hostAddress ?: "", "Network", 0))
        }
        return bonjour(::note)
    }

    // ------------------------------------------------------------------ 1. scan the local IPv4 network

    private fun scanV4(note: (String) -> Unit): List<InetAddress> {
        val targets = LinkedHashSet<String>()
        val seenIfaces = ArrayList<String>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces().toList()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) {
                    val a = ia.address
                    if (a !is Inet4Address) continue
                    seenIfaces.add("${ni.name}=${a.hostAddress}/${ia.networkPrefixLength}")
                    // skip link-local 169.254.x.x (no DHCP) and anything that is not a real LAN
                    if (a.isLinkLocalAddress || a.isAnyLocalAddress) continue
                    // scan the whole subnet, but never more than a /22 (1022 hosts)
                    val prefix = maxOf(22, ia.networkPrefixLength.toInt())
                    val ip = a.address.fold(0L) { acc, b -> (acc shl 8) or (b.toLong() and 0xFF) }
                    val mask = (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL
                    val net = ip and mask
                    val count = (1L shl (32 - prefix)) - 2
                    for (i in 1..count) {
                        val h = net + i
                        if (h == ip) continue
                        targets.add("${(h shr 24) and 255}.${(h shr 16) and 255}.${(h shr 8) and 255}.${h and 255}")
                    }
                }
            }
        } catch (e: Exception) { note("Network list failed: ${e.message}") }
        note("Mac IPv4 interfaces: " + if (seenIfaces.isEmpty()) "none" else seenIfaces.joinToString())
        if (targets.isEmpty()) { note("This Mac has no Wi-Fi/LAN address (IPv4). Join the same Wi-Fi as the iPhone."); return emptyList() }

        val hits = CopyOnWriteArrayList<InetAddress>()
        val errs = java.util.concurrent.ConcurrentHashMap<String, Int>()
        val pool = Executors.newFixedThreadPool(128)
        for (t in targets) pool.execute {
            try {
                val a = InetAddress.getByName(t)
                Socket().use { it.connect(InetSocketAddress(a, LOCKDOWN_PORT), 700) }
                hits.add(a)
            } catch (e: Exception) {
                // "Connection refused" = host is up but port closed (normal); "No route to host" on many hosts = macOS Local Network permission is OFF
                val k = e.message ?: e.javaClass.simpleName
                errs.merge(k, 1) { x, y -> x + y }
            }
        }
        pool.shutdown()
        pool.awaitTermination(25, TimeUnit.SECONDS)
        pool.shutdownNow()
        note("Scanned ${targets.size} addresses: ${hits.size} device(s) with port $LOCKDOWN_PORT open")
        if (hits.isEmpty()) note("Scan errors: " + errs.entries.sortedByDescending { it.value }.take(3).joinToString { "${it.key} x${it.value}" })
        return hits
    }

    // ------------------------------------------------------------------ 2. Bonjour name (IPv6 link-local)

    private fun bonjour(note: (String) -> Unit): List<MuxDevice> {
        if (!System.getProperty("os.name").lowercase().contains("mac")) return emptyList()
        val found = CopyOnWriteArrayList<Triple<Int, String, String>>()
        val proc = try {
            ProcessBuilder("/usr/bin/dns-sd", "-B", "_apple-mobdev2._tcp", "local").redirectErrorStream(true).start()
        } catch (e: Exception) { note("Bonjour tool failed: ${e.message}"); return emptyList() }
        val reader = Thread {
            try {
                proc.inputStream.bufferedReader().forEachLine { l ->
                    bonjourLine.find(l)?.let { m -> found.add(Triple(m.groupValues[1].toInt(), m.groupValues[2], m.groupValues[3])) }
                }
            } catch (_: Exception) {}
        }
        reader.isDaemon = true
        reader.start()
        Thread.sleep(3000)
        proc.destroy()
        reader.join(500)
        note("Bonjour: ${found.size} announcement(s) from iPhones")

        val result = ArrayList<MuxDevice>()
        val done = HashSet<String>()
        for ((idx, mac, v6) in found) {
            if (mac in done) continue
            val nifName = try { NetworkInterface.getByIndex(idx)?.name } catch (_: Exception) { null } ?: "?"
            if (nifName.startsWith("awdl") || nifName.startsWith("llw") || nifName.startsWith("utun")) {
                note("Bonjour: skipped interface $idx ($nifName): not a Wi-Fi/LAN link"); continue
            }
            val addr: InetAddress = (try {
                val raw = InetAddress.getByName(v6).address
                val nif = NetworkInterface.getByIndex(idx)
                if (nif != null) Inet6Address.getByAddress(null, raw, nif) else null
            } catch (_: Exception) { null }) ?: continue
            val ok = try {
                Socket().use { it.connect(InetSocketAddress(addr, LOCKDOWN_PORT), 2500) }
                true
            } catch (e: Exception) { note("Bonjour address on interface $idx ($nifName) did not answer: ${e.message}"); false }
            if (!ok) continue
            done.add(mac)
            val id = -(1 + (mac.hashCode() and 0x3FFFFFFF))
            UsbMux.directHosts[id] = addr
            note("Found an iPhone through Bonjour (interface $idx)")
            result.add(MuxDevice(id, mac, "Network", 0))
            break
        }
        return result
    }
}
