package dev.fakegeo.app

/** Desktop stand-ins for the few Android helpers the shared protocol code used. */
object SystemClock {
    fun elapsedRealtime(): Long = System.nanoTime() / 1_000_000L
}

object Base64 {
    const val NO_WRAP = 2
    const val DEFAULT = 0
    fun encodeToString(b: ByteArray, @Suppress("UNUSED_PARAMETER") flags: Int): String =
        java.util.Base64.getEncoder().encodeToString(b)
    fun decode(s: String, @Suppress("UNUSED_PARAMETER") flags: Int): ByteArray =
        java.util.Base64.getMimeDecoder().decode(s)
}
