package dev.fakegeo.app

import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.StandardProtocolFamily
import java.net.UnixDomainSocketAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.SocketChannel

/** An iPhone seen by the system's usbmuxd (macOS: built in; Windows: Apple Mobile Device Service). */
data class MuxDevice(val id: Int, val serial: String, val connection: String, val productId: Int)

/**
 * Desktop transport. The OS already runs "usbmuxd", which owns the USB cable and does the TCP part,
 * so unlike on Android we only ask it for a pipe to a port on the iPhone.
 */
object UsbMux {

    /** A byte pipe to a service on the iPhone: plain TCP, or TLS on top of it. */
    interface Stream {
        fun write(data: ByteArray)
        fun read(n: Int, timeoutMs: Int): ByteArray
        fun readSome(timeoutMs: Int): ByteArray
        fun close()
    }

    private val isWindows = System.getProperty("os.name").lowercase().contains("win")

    private class Raw(val inp: InputStream, val out: OutputStream, val closer: () -> Unit, val setTimeout: (Int) -> Unit)

    private fun openRaw(): Raw {
        if (isWindows) {
            val s = Socket()
            s.connect(InetSocketAddress("127.0.0.1", 27015), 3000)
            s.tcpNoDelay = true
            return Raw(s.getInputStream(), s.getOutputStream(), { s.close() }, { s.soTimeout = it })
        }
        val ch = SocketChannel.open(StandardProtocolFamily.UNIX)
        ch.connect(UnixDomainSocketAddress.of("/var/run/usbmuxd"))
        // Direct channel I/O: Channels.newInputStream/newOutputStream share one lock, so a pending read blocks every write.
        val inp = object : InputStream() {
            override fun read(): Int { val b = ByteArray(1); return if (read(b, 0, 1) < 0) -1 else b[0].toInt() and 0xFF }
            override fun read(b: ByteArray, off: Int, len: Int): Int = ch.read(ByteBuffer.wrap(b, off, len))
        }
        val out = object : OutputStream() {
            override fun write(b: Int) = write(byteArrayOf(b.toByte()), 0, 1)
            override fun write(b: ByteArray, off: Int, len: Int) {
                val bb = ByteBuffer.wrap(b, off, len); while (bb.hasRemaining()) ch.write(bb)
            }
        }
        return Raw(inp, out, { ch.close() }, { })
    }

    private var tag = 1

    private fun sendPlist(r: Raw, msg: Map<String, Any?>) {
        val body = Plist.encode(msg)
        val bb = ByteBuffer.allocate(16 + body.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(16 + body.size); bb.putInt(1); bb.putInt(8); bb.putInt(tag++)
        bb.put(body)
        r.out.write(bb.array()); r.out.flush()
    }

    private fun readExact(i: InputStream, n: Int): ByteArray {
        val b = ByteArray(n); var o = 0
        while (o < n) { val k = i.read(b, o, n - o); if (k < 0) throw IOException("usbmuxd closed the connection"); o += k }
        return b
    }

    private fun recvPlist(r: Raw): Map<String, Any?> {
        val h = ByteBuffer.wrap(readExact(r.inp, 16)).order(ByteOrder.LITTLE_ENDIAN)
        val len = h.getInt(0)
        if (len < 16 || len > 4_000_000) throw IOException("bad usbmuxd length $len")
        val body = readExact(r.inp, len - 16)
        return if (BPlist.isBinary(body)) BPlist.decode(body) else Plist.decode(body)
    }

    private fun request(msg: Map<String, Any?>): Map<String, Any?> {
        val r = openRaw()
        try { sendPlist(r, msg + mapOf("ClientVersionString" to "FakeGeo", "ProgName" to "FakeGeo", "kLibUSBMuxVersion" to 3L)); return recvPlist(r) }
        finally { r.closer() }
    }

    /** True if usbmuxd answers at all (on Windows it needs iTunes / Apple Devices installed). */
    fun available(): String? = try { request(mapOf("MessageType" to "ListDevices")); null } catch (e: Exception) {
        if (isWindows) "Apple Mobile Device Service not found. Install iTunes or the Apple Devices app."
        else "usbmuxd not reachable: ${e.message}"
    }

    /** The pairing macOS itself has saved for this iPhone, or null if there is none. */
    fun readPairRecord(udid: String): ByteArray? = try {
        request(mapOf("MessageType" to "ReadPairRecord", "PairRecordID" to udid))["PairRecordData"] as? ByteArray
    } catch (_: Exception) { null }

    /** Gives macOS's usbmuxd a pairing for this iPhone, so it lists the iPhone when it is on Wi-Fi. */
    fun savePairRecord(udid: String, deviceId: Int, data: ByteArray): Boolean = try {
        val r = request(mapOf("MessageType" to "SavePairRecord", "PairRecordID" to udid, "PairRecordData" to data, "DeviceID" to deviceId.toLong()))
        (r["Number"] as? Number)?.toInt() == 0
    } catch (_: Exception) { false }

    fun listDevices(): List<MuxDevice> {
        val r = request(mapOf("MessageType" to "ListDevices"))
        @Suppress("UNCHECKED_CAST")
        val list = r["DeviceList"] as? List<Map<String, Any?>> ?: return emptyList()
        return list.mapNotNull { d ->
            @Suppress("UNCHECKED_CAST")
            val p = d["Properties"] as? Map<String, Any?> ?: return@mapNotNull null
            val conn = p["ConnectionType"] as? String ?: "USB"
            MuxDevice(
                (d["DeviceID"] as? Long)?.toInt() ?: (p["DeviceID"] as? Long)?.toInt() ?: return@mapNotNull null,
                p["SerialNumber"] as? String ?: "", conn, (p["ProductID"] as? Long)?.toInt() ?: 0
            )
        }
    }

    /** Pipe to [port] on the iPhone. Blocking reads with timeouts, like the Android version. */
    private class PipeStream(private val raw: Raw) : Stream {
        private val q = java.util.concurrent.LinkedBlockingQueue<ByteArray>()
        @Volatile private var dead: String? = null
        private var rbuf = ByteArray(0)

        init {
            Thread {
                try {
                    val buf = ByteArray(65536)
                    while (true) { val n = raw.inp.read(buf); if (n < 0) break; q.put(buf.copyOf(n)) }
                    dead = "connection closed by the iPhone"
                } catch (e: Exception) { dead = e.message ?: "connection closed" }
                q.put(ByteArray(0))
            }.also { it.isDaemon = true }.start()
        }

        private fun fill(deadline: Long) {
            val left = deadline - SystemClock.elapsedRealtime()
            if (left <= 0) throw IOException("timeout waiting for the iPhone")
            val b = q.poll(left, java.util.concurrent.TimeUnit.MILLISECONDS)
            if (b == null) throw IOException("timeout waiting for the iPhone")
            if (b.isEmpty()) { q.put(b); throw IOException(dead ?: "connection closed by the iPhone") }
            rbuf += b
        }

        @Synchronized override fun write(data: ByteArray) { raw.out.write(data); raw.out.flush() }

        override fun read(n: Int, timeoutMs: Int): ByteArray {
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (rbuf.size < n) fill(end)
            val out = rbuf.copyOfRange(0, n); rbuf = rbuf.copyOfRange(n, rbuf.size); return out
        }

        override fun readSome(timeoutMs: Int): ByteArray {
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (rbuf.isEmpty()) fill(end)
            val out = rbuf; rbuf = ByteArray(0); return out
        }

        override fun close() { try { raw.closer() } catch (_: Exception) {} }
    }

    class MuxLink private constructor(private val deviceId: Int, val log: (String) -> Unit) {
        companion object {
            fun open(deviceId: Int, log: (String) -> Unit): MuxLink? {
                val err = available()
                if (err != null) { log(err); return null }
                return MuxLink(deviceId, log)
            }
        }

        fun handshake() = true
        fun close() {}

        fun connect(port: Int): Stream? {
            val raw = try { openRaw() } catch (e: Exception) { log("Cannot reach usbmuxd: ${e.message}"); return null }
            return try {
                sendPlist(raw, mapOf(
                    "MessageType" to "Connect", "ClientVersionString" to "FakeGeo", "ProgName" to "FakeGeo", "kLibUSBMuxVersion" to 3L,
                    "DeviceID" to deviceId.toLong(),
                    "PortNumber" to (((port and 0xFF) shl 8) or (port shr 8)).toLong()   // network byte order
                ))
                val r = recvPlist(raw)
                val n = (r["Number"] as? Long) ?: -1L
                log("usbmuxd: Connect(port $port) -> result $n")
                if (n != 0L) {
                    log("Connection to port $port refused (usbmuxd result $n). Is the iPhone unlocked?")
                    raw.closer(); null
                } else PipeStream(raw)
            } catch (e: Exception) { log("connect($port) failed: ${e.message}"); try { raw.closer() } catch (_: Exception) {}; null }
        }
    }
}
