package dev.fakegeo.app

import java.io.File

/**
 * One log for everything: the last lines are kept in memory (the map screen shows them) and every line is
 * appended to a file the user can send:  ~/Library/Logs/FakeGeo/fakegeo.log  (macOS) or ~/.fakegeo/logs/ (others).
 */
object FileLog {
    private val isMac = System.getProperty("os.name").lowercase().contains("mac")

    val dir: File by lazy {
        val home = System.getProperty("user.home") ?: "."
        File(home, if (isMac) "Library/Logs/FakeGeo" else ".fakegeo/logs").also { it.mkdirs() }
    }

    val file: File by lazy {
        File(dir, "fakegeo.log").also {
            // keep the file small: start fresh when it grew past 2 MB
            try { if (it.exists() && it.length() > 2_000_000) it.writeText("") } catch (_: Exception) {}
        }
    }

    private val ring = ArrayDeque<String>()

    @Synchronized
    fun add(line: String) {
        ring.addLast(line)
        while (ring.size > 600) ring.removeFirst()
        try { file.appendText(line + "\n") } catch (_: Exception) {}
    }

    @Synchronized
    fun text(): String = ring.joinToString("\n")

    @Synchronized
    fun clearScreen() { ring.clear() }
}
