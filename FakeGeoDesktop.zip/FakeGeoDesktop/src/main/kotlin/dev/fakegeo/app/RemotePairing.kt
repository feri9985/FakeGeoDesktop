package dev.fakegeo.app

import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList

/**
 * RemotePairing, STAGE 1: only DISCOVERY. Changes nothing on the iPhone and does not pair.
 * iOS 17+ offers Wi-Fi access through the Bonjour service "_remotepairing._tcp" (not "_apple-mobdev2").
 * This stage finds that service, resolves host + port, and checks that a TCP connection opens.
 * Uses the macOS tool dns-sd (same approach as WifiDiscovery).
 */
object RemotePairing {
    private val addLine = Regex("""\bAdd\s+\d+\s+(\d+)\s+\S+\s+_remotepairing\._tcp\.\s+(.+?)\s*$""")
    private val reachLine = Regex("""can be reached at\s+(\S+?):(\d+)""")

    /** Runs dns-sd with [args] for [seconds] and returns every output line. */
    private fun dnsSd(seconds: Int, vararg args: String): List<String> {
        val lines = CopyOnWriteArrayList<String>()
        val proc = try {
            ProcessBuilder(listOf("/usr/bin/dns-sd") + args).redirectErrorStream(true).start()
        } catch (e: Exception) { lines.add("dns-sd failed to start: ${e.message}"); return lines }
        val t = Thread {
            try { proc.inputStream.bufferedReader().forEachLine { lines.add(it) } } catch (_: Exception) {}
        }
        t.isDaemon = true; t.start()
        Thread.sleep(seconds * 1000L)
        proc.destroy()
        t.join(500)
        return lines
    }

    fun discover(log: (String) -> Unit) {
        if (!System.getProperty("os.name").lowercase().contains("mac")) { log("RemotePairing stage 1 runs on macOS only."); return }
        log("[1/3] Looking for _remotepairing._tcp (5 s)…")
        val found = LinkedHashMap<String, Int>()   // instance name -> interface index
        for (l in dnsSd(5, "-B", "_remotepairing._tcp", "local")) {
            addLine.find(l)?.let { m -> found.putIfAbsent(m.groupValues[2], m.groupValues[1].toInt()) }
        }
        if (found.isEmpty()) {
            log("Nothing found. Make sure: iPhone unlocked, screen on, same Wi-Fi as the Mac, and FakeGeo allowed under System Settings > Privacy & Security > Local Network.")
            return
        }
        for ((name, idx) in found) {
            val ifName = try { NetworkInterface.getByIndex(idx)?.name } catch (_: Exception) { null } ?: "?"
            log("Found: \"$name\" on interface $idx ($ifName)")
        }

        for ((name, idx) in found) {
            val ifName = try { NetworkInterface.getByIndex(idx)?.name } catch (_: Exception) { null } ?: "?"
            log("[2/3] Resolving \"$name\" …")
            val out = dnsSd(4, "-L", name, "_remotepairing._tcp", "local")
            val m = out.firstNotNullOfOrNull { reachLine.find(it) }
            if (m == null) { log("Could not resolve. dns-sd said: " + out.takeLast(3).joinToString(" | ")); continue }
            val host = m.groupValues[1]
            val port = m.groupValues[2].toInt()
            log("Host $host, port $port")
            out.filter { it.contains("=") && !it.contains("reached") }.take(4).forEach { log("TXT: ${it.trim().take(140)}") }

            log("[3/3] Testing TCP to $host:$port …")
            val addrs: List<InetAddress> = try { InetAddress.getAllByName(host).toList() } catch (e: Exception) { log("Address lookup failed: ${e.message}"); emptyList() }
            for (a0 in addrs) {
                val a: InetAddress = if (a0 is Inet6Address && a0.isLinkLocalAddress) {
                    try { NetworkInterface.getByIndex(idx)?.let { Inet6Address.getByAddress(null, a0.address, it) } ?: a0 } catch (_: Exception) { a0 }
                } else a0
                val ok = try { Socket().use { it.connect(InetSocketAddress(a, port), 3000) }; "OPEN" } catch (e: Exception) { "no (${e.message})" }
                log("  ${a0.hostAddress} ($ifName): $ok")
            }
        }
        log("Stage 1 finished. Send me this whole text.")
    }
}
