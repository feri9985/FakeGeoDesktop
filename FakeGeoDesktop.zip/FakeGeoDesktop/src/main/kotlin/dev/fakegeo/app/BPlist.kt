package dev.fakegeo.app

/** Minimal binary plist reader (usbmuxd on some systems answers in "bplist00" instead of XML). */
object BPlist {
    fun isBinary(b: ByteArray) = b.size > 8 && String(b, 0, 6, Charsets.US_ASCII) == "bplist"

    private fun be(b: ByteArray, off: Int, n: Int): Long { var v = 0L; for (i in 0 until n) v = (v shl 8) or (b[off + i].toLong() and 0xFF); return v }

    @Suppress("UNCHECKED_CAST")
    fun decode(b: ByteArray): Map<String, Any?> {
        val t = b.size - 32
        val offSize = b[t + 6].toInt(); val refSize = b[t + 7].toInt()
        val n = be(b, t + 8, 8).toInt(); val top = be(b, t + 16, 8).toInt(); val tbl = be(b, t + 24, 8).toInt()
        fun objOff(i: Int) = be(b, tbl + i * offSize, offSize).toInt()
        fun parse(i: Int): Any? {
            var p = objOff(i)
            val m = b[p].toInt() and 0xFF; val hi = m shr 4; var lo = m and 0xF; p++
            fun len(): Int {
                if (lo != 0xF) return lo
                val sz = 1 shl (b[p].toInt() and 0xF); val v = be(b, p + 1, sz).toInt(); p += 1 + sz; return v
            }
            return when (hi) {
                0x0 -> when (m) { 0x08 -> false; 0x09 -> true; else -> null }
                0x1 -> be(b, p, 1 shl lo)
                0x2 -> if (lo == 3) java.lang.Double.longBitsToDouble(be(b, p, 8)) else java.lang.Float.intBitsToFloat(be(b, p, 4).toInt()).toDouble()
                0x4 -> { val l = len(); b.copyOfRange(p, p + l) }
                0x5 -> { val l = len(); String(b, p, l, Charsets.US_ASCII) }
                0x6 -> { val l = len(); String(b, p, l * 2, Charsets.UTF_16BE) }
                0xA -> { val l = len(); (0 until l).map { parse(be(b, p + it * refSize, refSize).toInt()) } }
                0xD -> {
                    val l = len(); val mp = LinkedHashMap<String, Any?>()
                    for (k in 0 until l) {
                        val ki = be(b, p + k * refSize, refSize).toInt(); val vi = be(b, p + (l + k) * refSize, refSize).toInt()
                        mp[parse(ki).toString()] = parse(vi)
                    }
                    mp
                }
                else -> null
            }
        }
        check(n > 0)
        return (parse(top) as? Map<String, Any?>) ?: emptyMap()
    }
}
