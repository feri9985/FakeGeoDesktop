package dev.fakegeo.app

import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** What we know about one iPhone/iPad: model identifier (iPhone16,1), the owner's name for it, the iOS version. */
data class DevInfo(val product: String, val deviceName: String, val ios: String) {
    /** "iPhone 15 Pro"; the raw identifier when the model is newer than this table. */
    val model: String get() = DeviceInfo.marketingName(product)
}

object DeviceInfo {
    private val cache = ConcurrentHashMap<String, DevInfo>()   // UDID -> info
    private val file get() = File(System.getProperty("user.home") ?: ".", ".fakegeo/devices.tsv")

    init {
        try {
            file.readLines().forEach { line ->
                val t = line.split('\t')
                if (t.size >= 4) cache[t[0]] = DevInfo(t[1], t[2], t[3])
            }
        } catch (_: Exception) {}
    }

    private fun save() {
        try {
            file.parentFile?.mkdirs()
            file.writeText(cache.entries.joinToString("\n") { (k, v) -> "$k\t${v.product}\t${v.deviceName}\t${v.ios}" } + "\n")
        } catch (_: Exception) {}
    }

    private fun clean(s: String) = s.replace('\t', ' ').replace('\n', ' ').trim()

    fun cached(serial: String): DevInfo? = if (serial.isEmpty()) null else cache[serial]

    /** Reads the info from the iPhone (talks to it: call it off the screen thread) or returns what was saved from an earlier time. */
    fun lookup(d: MuxDevice): DevInfo? {
        cached(d.serial)?.let { return it }
        if (d.id < 0) return null
        val m = IosPairing.readInfo(d.id) ?: return null
        val info = DevInfo(clean(m["ProductType"] ?: ""), clean(m["DeviceName"] ?: ""), clean(m["ProductVersion"] ?: ""))
        val key = d.serial.ifEmpty { m["UniqueDeviceID"] ?: return info }
        cache[key] = info
        save()
        return info
    }

    /** "iPhone 15 Pro" (or "iPhone (USB)" while the model is not known yet). */
    fun title(d: MuxDevice, info: DevInfo?): String {
        val how = if (d.connection == "Network") "Wi-Fi" else "USB"
        return if (info != null && info.product.isNotEmpty()) info.model else "iPhone ($how)"
    }

    /** Second line: the owner's name for the iPhone, iOS version, connection. */
    fun subtitle(d: MuxDevice, info: DevInfo?): String {
        val how = if (d.connection == "Network") "Wi-Fi" else "USB"
        val parts = ArrayList<String>()
        if (info != null) {
            if (info.deviceName.isNotEmpty()) parts.add(info.deviceName)
            if (info.ios.isNotEmpty()) parts.add("iOS ${info.ios}")
        }
        parts.add(how)
        if (d.serial.isNotEmpty()) parts.add(d.serial.take(13) + "…")
        return parts.joinToString("  ·  ")
    }

    private val models: Map<String, String> = mapOf(
        "iPhone10,1" to "iPhone 8", "iPhone10,4" to "iPhone 8", "iPhone10,2" to "iPhone 8 Plus", "iPhone10,5" to "iPhone 8 Plus",
        "iPhone10,3" to "iPhone X", "iPhone10,6" to "iPhone X",
        "iPhone11,2" to "iPhone XS", "iPhone11,4" to "iPhone XS Max", "iPhone11,6" to "iPhone XS Max", "iPhone11,8" to "iPhone XR",
        "iPhone12,1" to "iPhone 11", "iPhone12,3" to "iPhone 11 Pro", "iPhone12,5" to "iPhone 11 Pro Max", "iPhone12,8" to "iPhone SE (2nd gen)",
        "iPhone13,1" to "iPhone 12 mini", "iPhone13,2" to "iPhone 12", "iPhone13,3" to "iPhone 12 Pro", "iPhone13,4" to "iPhone 12 Pro Max",
        "iPhone14,4" to "iPhone 13 mini", "iPhone14,5" to "iPhone 13", "iPhone14,2" to "iPhone 13 Pro", "iPhone14,3" to "iPhone 13 Pro Max",
        "iPhone14,6" to "iPhone SE (3rd gen)", "iPhone14,7" to "iPhone 14", "iPhone14,8" to "iPhone 14 Plus",
        "iPhone15,2" to "iPhone 14 Pro", "iPhone15,3" to "iPhone 14 Pro Max", "iPhone15,4" to "iPhone 15", "iPhone15,5" to "iPhone 15 Plus",
        "iPhone16,1" to "iPhone 15 Pro", "iPhone16,2" to "iPhone 15 Pro Max",
        "iPhone17,1" to "iPhone 16 Pro", "iPhone17,2" to "iPhone 16 Pro Max", "iPhone17,3" to "iPhone 16", "iPhone17,4" to "iPhone 16 Plus",
        "iPhone17,5" to "iPhone 16e",
        "iPhone18,1" to "iPhone 17 Pro", "iPhone18,2" to "iPhone 17 Pro Max", "iPhone18,3" to "iPhone 17", "iPhone18,4" to "iPhone Air"
    )

    fun marketingName(product: String): String = models[product] ?: product.ifEmpty { "iPhone" }
}
