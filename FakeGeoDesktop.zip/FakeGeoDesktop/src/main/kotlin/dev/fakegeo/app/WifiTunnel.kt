package dev.fakegeo.app

import java.io.File
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Wi-Fi mode (macOS).
 *
 * The iPhone (iOS 17+) only offers its developer services through a CoreDevice tunnel. Over Wi-Fi that tunnel is
 * created by pymobiledevice3 ("lockdown start-tunnel" or "remote start-tunnel -t wifi"), which needs root.
 * This object
 *   1. starts ONE small supervisor script as root (one macOS password prompt per app launch). The supervisor
 *      restarts the tunnel by itself whenever it drops (iPhone sleeps, Wi-Fi blip) and stops when the app quits,
 *   2. reads the tunnel's "RSD Address / RSD Port" from a log file in ~/Library/Logs/FakeGeo,
 *   3. runs the RSD handshake + the RSDCheckin + DTX LocationSimulation (the app's own code) over normal sockets.
 */
object WifiTunnel {
    class Outcome(val report: String, val fatal: Boolean)
    private class Fatal(msg: String) : Exception(msg)

    /** One tunnel (one helper script, one set of files) per iPhone. Key = the iPhone's UDID, or "any" when it is not known. */
    private fun keyOf(udid: String) = udid.filter { it.isLetterOrDigit() || it == '-' }.ifEmpty { "any" }
    private fun fileOf(key: String, ext: String) = File(FileLog.dir, "wifi-tunnel-$key.$ext")

    private val addrRe = Regex("""RSD Address:\s*([0-9A-Fa-f:.]+(?:%\w+)?)""")
    private val portRe = Regex("""RSD Port:\s*(\d+)""")
    private val ansiRe = Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]")

    private val isMac = System.getProperty("os.name").lowercase().contains("mac")

    /** key -> when this app launch started that tunnel's helper (so its pid file can be trusted). */
    private val started = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val launchLock = Any()
    @Volatile private var lastCancelAt = 0L
    @Volatile private var hookAdded = false
    /** Does dtservicehub need the "RSDCheckin" message first? null = not learned yet. */
    @Volatile private var needsCheckin: Boolean? = null
    @Volatile private var binCache: String? = null

    // ------------------------------------------------------------------ a socket as the Stream the RSD/DTX code expects

    private class SockStream(private val s: Socket) : UsbMux.Stream {
        private val q = LinkedBlockingQueue<ByteArray>()
        @Volatile private var dead: String? = null
        private var rbuf = ByteArray(0)

        init {
            s.tcpNoDelay = true
            try { s.keepAlive = true } catch (_: Exception) {}
            Thread {
                try {
                    val inp = s.getInputStream()
                    val buf = ByteArray(65536)
                    while (true) { val n = inp.read(buf); if (n < 0) break; q.put(buf.copyOf(n)) }
                    dead = "connection closed by the iPhone"
                } catch (e: Exception) { dead = e.message ?: "connection closed" }
                q.put(ByteArray(0))
            }.also { it.isDaemon = true }.start()
        }

        private fun fill(deadline: Long) {
            val left = deadline - SystemClock.elapsedRealtime()
            if (left <= 0) throw IOException("timeout waiting for the iPhone")
            val b = q.poll(left, TimeUnit.MILLISECONDS) ?: throw IOException("timeout waiting for the iPhone")
            if (b.isEmpty()) { q.put(b); throw IOException(dead ?: "connection closed by the iPhone") }
            rbuf += b
        }

        @Synchronized override fun write(data: ByteArray) { val o = s.getOutputStream(); o.write(data); o.flush() }

        override fun read(n: Int, timeoutMs: Int): ByteArray {
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (rbuf.size < n) fill(end)
            val out = rbuf.copyOfRange(0, n); rbuf = rbuf.copyOfRange(n, rbuf.size); return out
        }

        override fun readSome(timeoutMs: Int): ByteArray {
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (rbuf.isEmpty()) fill(end)
            val out = rbuf; rbuf = ByteArray(0); return out
        }

        override fun close() { try { s.close() } catch (_: Exception) {} }
    }

    // ------------------------------------------------------------------ small helpers

    private fun alive(host: String, port: Int): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(InetAddress.getByName(host), port), 2000) }
        true
    } catch (_: Exception) { false }

    /** Shell-quote: 'text' with every ' turned into '\'' (works for any path, also with spaces). */
    private fun shq(s: String) = "'" + s.replace("'", "'\\''") + "'"

    /** Escape text for an AppleScript string literal. */
    private fun asq(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")

    /** Runs a command, returns its output; never waits longer than [seconds] (a hanging shell cannot freeze the app). */
    private fun capture(cmd: List<String>, seconds: Long): String {
        val out = StringBuffer()
        try {
            val pr = ProcessBuilder(cmd).redirectErrorStream(true).start()
            val t = Thread { try { pr.inputStream.bufferedReader().forEachLine { out.append(it).append('\n') } } catch (_: Exception) {} }
            t.isDaemon = true; t.start()
            if (!pr.waitFor(seconds, TimeUnit.SECONDS)) pr.destroyForcibly()
            t.join(500)
        } catch (_: Exception) {}
        return out.toString()
    }

    private fun readTunnelLog(key: String): String = try { ansiRe.replace(fileOf(key, "log").readText(), "") } catch (_: Exception) { "" }

    private fun tailOf(text: String, n: Int): String =
        text.trim().lines().filter { it.isNotBlank() }.takeLast(n).joinToString(" | ") { it.trim().take(200) }

    private fun endpointFrom(text: String): Pair<String, Int>? {
        val a = addrRe.findAll(text).lastOrNull() ?: return null
        val pt = portRe.findAll(text).lastOrNull { it.range.first > a.range.first } ?: return null
        val port = pt.groupValues[1].toIntOrNull() ?: return null
        return a.groupValues[1] to port
    }

    /** Finds the pymobiledevice3 program (also when the app was started from Finder, with a short PATH). */
    fun locate(): String? {
        binCache?.let { if (File(it).canExecute()) return it }
        val home = System.getProperty("user.home") ?: ""
        val cands = LinkedHashSet<String>()
        capture(listOf("/bin/zsh", "-lc", "command -v pymobiledevice3"), 6).trim().lines()
            .lastOrNull { it.trim().startsWith("/") }?.let { cands.add(it.trim()) }
        cands.add("/opt/homebrew/bin/pymobiledevice3")
        cands.add("/usr/local/bin/pymobiledevice3")
        cands.add("$home/.local/bin/pymobiledevice3")                                   // pipx
        cands.add("$home/.local/pipx/venvs/pymobiledevice3/bin/pymobiledevice3")
        cands.add("$home/.pyenv/shims/pymobiledevice3")
        cands.add("$home/miniconda3/bin/pymobiledevice3"); cands.add("$home/anaconda3/bin/pymobiledevice3")
        File("/Library/Frameworks/Python.framework/Versions").listFiles()?.sortedByDescending { it.name }
            ?.forEach { cands.add("${it.path}/bin/pymobiledevice3") }
        File("$home/Library/Python").listFiles()?.sortedByDescending { it.name }
            ?.forEach { cands.add("${it.path}/bin/pymobiledevice3") }
        val found = cands.firstOrNull { File(it).canExecute() }
        binCache = found
        return found
    }

    private fun supervisorRunning(key: String): Boolean {
        val t = started[key] ?: return false
        val pid = try { fileOf(key, "pid").readText().trim().toLong() } catch (_: Exception) { return System.currentTimeMillis() - t < 8000 }
        return ProcessHandle.of(pid).map { it.isAlive }.orElse(false)
    }

    private fun stopSupervisor(key: String) {
        try { fileOf(key, "stop").writeText("1") } catch (_: Exception) {}
        started.remove(key)
    }

    // ------------------------------------------------------------------ the root supervisor

    /** Prepares the files and builds the shell command that starts the helper of one iPhone in the background. */
    /** Keys whose pymobiledevice3 does not know --udid (older version): they start without it. */
    private val noUdidKeys: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    private fun supervisorCmd(bin: String, key: String, udid: String, useUdid: Boolean): String {
        val home = System.getProperty("user.home") ?: throw Fatal("Cannot find your home folder.")
        FileLog.dir.mkdirs()
        val logF = fileOf(key, "log"); val stopF = fileOf(key, "stop"); val skipF = fileOf(key, "skip"); val pidF = fileOf(key, "pid")
        stopF.delete(); skipF.delete(); pidF.delete()
        try {
            logF.writeText("")
            logF.setReadable(false, false); logF.setReadable(true, true); logF.setWritable(false, false); logF.setWritable(true, true)
        } catch (_: Exception) {}

        val app = ProcessHandle.current().pid()
        val stop = shq(stopF.path)
        val skip = shq(skipF.path)
        val b = shq(bin)
        // With several iPhones every tunnel must name its iPhone (--udid). A UDID has only letters, digits and "-", so it needs no quoting.
        // Always name the iPhone when we know it: without --udid pymobiledevice3 picks ANY iPhone on the network (it tunnelled the wrong one).
        val u = udid.takeIf { key !in noUdidKeys && it.matches(Regex("[0-9A-Za-z-]{8,64}")) }
        val udidArg = if (u != null) " --udid $u" else ""
        // Plain /bin/sh. Tries "lockdown start-tunnel" first (and, for a single iPhone, "remote start-tunnel -t wifi" next),
        // and starts over whenever a tunnel ends. Everything stops when this app quits or the stop file appears.
        val script =
            "trap '' HUP; " +
            "echo \"[fakegeo] helper started: pid \$\$, uid \$(id -u), app $app, device $key\"; " +
            "echo \$\$ > ${shq(pidF.path)}; " +
            "export PYTHONUNBUFFERED=1 HOME=${shq(home)}; " +
            "alive() { kill -0 $app 2>/dev/null && [ ! -e $stop ]; }; " +
            "run() { \"\$@\" & P=\$!; " +
                "while kill -0 \$P 2>/dev/null && alive && [ ! -e $skip ]; do sleep 1; done; " +
                "kill \$P 2>/dev/null; sleep 1; kill -0 \$P 2>/dev/null && kill -9 \$P 2>/dev/null; " +
                "wait \$P 2>/dev/null; rm -f $skip; }; " +
            "alive || echo \"[fakegeo] not starting: the app (pid $app) is gone or the stop file exists\"; " +
            "while alive; do " +
                "echo '[fakegeo] start: lockdown start-tunnel$udidArg'; run $b lockdown start-tunnel$udidArg; " +
                "alive || break; sleep 2; " +
                (if (udidArg.isEmpty()) "echo '[fakegeo] start: remote start-tunnel -t wifi'; run $b remote start-tunnel -t wifi; " else "") +
                "sleep 3; " +
            "done"
        // No "nohup": on macOS it refuses to run without a terminal ("can't detach from console") and the helper never started.
        // "do shell script" has no terminal, so there is no SIGHUP to survive; the script ignores HUP anyway.
        return "/bin/sh -c ${shq(script)} >> ${shq(logF.path)} 2>&1 < /dev/null &"
    }

    /** Runs the commands as root with ONE macOS password prompt. */
    private fun launch(cmds: List<String>, p: (String) -> Unit) {
        val osa = "do shell script \"" + asq(cmds.joinToString(" ")) + "\" with administrator privileges"
        p("macOS now asks for your Mac password (once per app launch" + (if (cmds.size > 1) ", for all ${cmds.size} iPhones" else "") + ").")
        val pr = ProcessBuilder("/usr/bin/osascript", "-e", osa).redirectErrorStream(true).start()
        val outBuf = StringBuffer()
        val rt = Thread { try { pr.inputStream.bufferedReader().forEachLine { outBuf.append(it).append(' ') } } catch (_: Exception) {} }
        rt.isDaemon = true; rt.start()
        if (!pr.waitFor(180, TimeUnit.SECONDS)) { pr.destroyForcibly(); lastCancelAt = System.currentTimeMillis(); throw Fatal("Timed out waiting for the macOS password prompt.") }
        rt.join(500)
        if (pr.exitValue() != 0) {
            lastCancelAt = System.currentTimeMillis()
            throw Fatal("The tunnel was not started (${outBuf.toString().trim().take(140)}). Was the password prompt cancelled?")
        }
        if (!hookAdded) {
            hookAdded = true
            Runtime.getRuntime().addShutdownHook(Thread { for (k in started.keys) try { fileOf(k, "stop").writeText("1") } catch (_: Exception) {} })
        }
    }

    /**
     * Starts the tunnel helpers of several iPhones with ONE password prompt (call it before the sessions start).
     * Problems are not thrown: every session shows its own error.
     */
    fun prepare(udids: List<String>, useUdid: Boolean) {
        if (!isMac) return
        try {
            val bin = locate() ?: return
            synchronized(launchLock) {
                val need = udids.filter { !supervisorRunning(keyOf(it)) }
                if (need.isEmpty()) return
                MockState.log("iOS Wi-Fi: starting ${need.size} tunnel helper(s) with $bin")
                val cmds = need.map { supervisorCmd(bin, keyOf(it), it, useUdid) }
                launch(cmds) { MockState.log("iOS Wi-Fi: $it") }
                val now = System.currentTimeMillis()
                need.forEach { started[keyOf(it)] = now }
            }
        } catch (e: Exception) { MockState.log("iOS Wi-Fi: could not start the tunnel helpers: ${e.message}") }
    }

    /** Waits until the helper has published a tunnel that really accepts connections. */
    private fun waitForEndpoint(key: String, p: (String) -> Unit, totalMs: Long): Pair<String, Int> {
        val start = SystemClock.elapsedRealtime()
        var skipped = false
        var lastNote = start
        var unreachable = ""
        while (true) {
            val text = readTunnelLog(key)
            val ep = endpointFrom(text)
            if (ep != null) {
                if (alive(ep.first, ep.second)) return ep
                unreachable = "[${ep.first}]:${ep.second} is announced but does not accept connections yet"
            }
            val now = SystemClock.elapsedRealtime()
            val waited = now - start
            if (waited > 12_000 && !text.contains("[fakegeo] helper started")) {
                stopSupervisor(key)
                throw Fatal("The tunnel helper did not start (nothing from it in the tunnel log). Tunnel log: ${tailOf(text, 3)}. Full log: ${FileLog.file.path}")
            }
            if (text.contains("No such option", true) && text.contains("--udid")) {
                stopSupervisor(key)
                noUdidKeys.add(key)
                throw Fatal("This pymobiledevice3 does not accept --udid for 'lockdown start-tunnel', so several iPhones cannot use Wi-Fi at once. " +
                    "Update it (pip3 install -U pymobiledevice3) or use one iPhone over Wi-Fi.")
            }
            if (!skipped && waited > 35_000) {
                p("The first tunnel type did not come up in 35 s: trying the other one.")
                try { fileOf(key, "skip").writeText("1") } catch (_: Exception) {}
                skipped = true
            }
            if (now - lastNote > 10_000) {
                lastNote = now
                p("Waiting for the tunnel… ${(waited / 1000)} s. " + (if (unreachable.isNotEmpty()) "$unreachable. " else "") + "Tunnel log: " + tailOf(text, 2))
            }
            if (waited > totalMs) {
                val tail = tailOf(text, 4)
                stopSupervisor(key)
                throw Fatal(
                    "The Wi-Fi tunnel did not start. Tunnel log: $tail  |  Check: iPhone unlocked with the screen on, same Wi-Fi as the Mac, " +
                        "Developer Mode on, and 'Turn on Wi-Fi for this iPhone' done once with the cable. Full log: ${FileLog.file.path}"
                )
            }
            if (IosSession.stopRequested()) throw Fatal("Stopped.")
            Thread.sleep(700)
        }
    }

    private fun ensureTunnel(key: String, udid: String, useUdid: Boolean, p: (String) -> Unit): Pair<String, Int> {
        // 1) a tunnel is already up (the helper keeps it alive): use it, no password needed
        endpointFrom(readTunnelLog(key))?.let { ep ->
            if (supervisorRunning(key) && alive(ep.first, ep.second)) { p("Using the running Wi-Fi tunnel [${ep.first}]:${ep.second}"); return ep }
        }
        // 2) the helper runs but the tunnel is down: it restarts it by itself, just wait
        if (supervisorRunning(key)) {
            p("Waiting for the tunnel helper…")
            return waitForEndpoint(key, p, 75_000).also { p("Tunnel is up: [${it.first}]:${it.second}") }
        }
        // 3) first start in this app launch
        val bin = locate()
            ?: throw Fatal("pymobiledevice3 was not found. Install it once in Terminal:  pip3 install -U pymobiledevice3   (then press the button again)")
        synchronized(launchLock) {
            if (!supervisorRunning(key)) {             // another iPhone's session may have just started it (see prepare)
                if (System.currentTimeMillis() - lastCancelAt < 30_000) throw Fatal("The password prompt was cancelled. Press Teleport again to retry.")
                val ver = capture(listOf(bin, "version"), 10).trim().lines().lastOrNull { it.isNotBlank() }?.take(60) ?: ""
                if (ver.isNotEmpty()) p("pymobiledevice3 version: $ver")
                p("Starting the Wi-Fi tunnel with $bin")
                val cmd = supervisorCmd(bin, key, udid, useUdid)
                launch(listOf(cmd), p)
                started[key] = System.currentTimeMillis()
            }
        }
        return waitForEndpoint(key, p, 75_000).also { p("Tunnel is up: [${it.first}]:${it.second}") }
    }

    // ------------------------------------------------------------------ connect, handshake, location

    private fun hintFor(msg: String, p: (String) -> Unit) {
        if (msg.contains("No route to host", true) || msg.contains("Operation not permitted", true) || msg.contains("Network is unreachable", true))
            p("Hint: macOS may be blocking this app from the local network. Open System Settings > Privacy & Security > Local Network " +
                "and switch FakeGeo ON (if you start it with 'gradle run', switch on Terminal / your IDE instead), then try again.")
    }

    private fun openSock(addr: InetAddress, port: Int, p: (String) -> Unit): SockStream {
        var last: Exception? = null
        for (i in 1..3) {
            val s = Socket()
            try {
                s.connect(InetSocketAddress(addr, port), 6000)
                return SockStream(s)
            } catch (e: Exception) {
                last = e
                try { s.close() } catch (_: Exception) {}
                p("connect to [${addr.hostAddress}]:$port failed (try $i/3): ${e.message}")
                if (i < 3) Thread.sleep(1000)
            }
        }
        hintFor(last?.message ?: "", p)
        throw IOException("could not connect to [${addr.hostAddress}]:$port: ${last?.message}")
    }

    /** Opens dtservicehub and runs the live location loop. Learns whether the "RSDCheckin" message is needed. */
    private fun runDtx(addr: InetAddress, hub: Int, rsd: Rsd.Result, p: (String) -> Unit): Boolean {
        val modes = when (needsCheckin) { true -> listOf(true); false -> listOf(false); null -> listOf(true, false) }
        var normal = false
        for (useCheckin in modes) {
            Dtx.liveOpened = false
            p("Connecting to dtservicehub (port $hub)" + if (useCheckin) " with RSDCheckin…" else " without RSDCheckin…")
            val d = openSock(addr, hub, p)
            try {
                if (useCheckin && !Rsd.checkin(d, p)) {
                    if (needsCheckin == null) continue          // learn: try the other way
                    return false
                }
                normal = Dtx.live(d, { _ -> rsd.keepAlive(1) }, p)
                if (Dtx.liveOpened) { needsCheckin = useCheckin; return normal }
                // the channel never opened: try the other way, if there is one
            } catch (e: IOException) {
                p("DTX error: ${e.message}")
                if (Dtx.liveOpened) { needsCheckin = useCheckin; return false }
            } finally { d.close() }
        }
        return normal
    }

    /** [udid] picks the iPhone's tunnel (empty = the only one); [useUdid] = name the iPhone to pymobiledevice3 (needed with several). */
    private val retriedNoUdid: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    fun run(udid: String = "", useUdid: Boolean = false): Outcome {
        val sb = StringBuilder()
        fun p(s: String) { sb.appendLine(s); MockState.log("${IosSession.tag()}iOS Wi-Fi: $s") }
        if (!isMac) return Outcome("Wi-Fi mode works on macOS only.", true)
        val key = keyOf(udid)
        try {
            val (host, port) = ensureTunnel(key, udid, useUdid, ::p)
            val addr = InetAddress.getByName(host)
            p("Connecting to the iPhone (RSD) [$host]:$port …")
            val c = openSock(addr, port, ::p)
            try {
                val rsd = Rsd.handshake(c, ::p)
                val info = rsd?.info
                if (rsd == null || info == null) { p("RSD handshake failed."); return Outcome(sb.toString(), false) }
                val props = info["Properties"] as? Map<*, *>
                val got = props?.get("UniqueDeviceID")?.toString().orEmpty()
                fun norm(x: String) = x.replace("-", "").lowercase()
                if (udid.isNotEmpty() && got.isNotEmpty() && norm(got) != norm(udid)) {
                    p("The tunnel reached a DIFFERENT iPhone ($got, ${props?.get("ThinningProductType") ?: "?"}) than the selected one ($udid). Restarting the tunnel helper for this iPhone.")
                    stopSupervisor(key)
                    return Outcome(sb.toString(), false)
                }
                val hub = ((info["Services"] as? Map<*, *>)?.get("com.apple.instruments.dtservicehub") as? Map<*, *>)
                    ?.get("Port")?.toString()?.toIntOrNull()
                if (hub == null) { p("The iPhone does not offer dtservicehub. Is Developer Mode on and the disk image mounted?"); return Outcome(sb.toString(), false) }
                val normal = runDtx(addr, hub, rsd, ::p)
                p(if (normal) "Live session ended normally." else "Live session broke; it will reconnect.")
            } finally { c.close() }
        } catch (e: Fatal) {
            if (key in noUdidKeys && !useUdid && !retriedNoUdid.contains(key)) {
                retriedNoUdid.add(key)
                p("Old pymobiledevice3 (no --udid): trying without it. With several iPhones on the network it may pick the wrong one; update it: pip3 install -U pymobiledevice3")
                return Outcome(sb.toString(), false)
            }
            p(e.message ?: "Wi-Fi tunnel error")
            return Outcome(sb.toString(), true)
        } catch (e: Exception) {
            p("ERROR: ${e.javaClass.simpleName}: ${e.message}")
            hintFor(e.message ?: "", ::p)
        }
        return Outcome(sb.toString(), false)
    }
}
