package dev.fakegeo.app

import java.io.File
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Wi-Fi mode (macOS).
 *
 * The iPhone (iOS 17+) only offers its developer services through a CoreDevice tunnel. Over Wi-Fi that tunnel is
 * created by pymobiledevice3 ("lockdown start-tunnel" or "remote start-tunnel -t wifi"), which needs root.
 * This object
 *   1. starts ONE small supervisor script as root (one macOS password prompt per app launch). The supervisor
 *      restarts the tunnel by itself whenever it drops (iPhone sleeps, Wi-Fi blip) and stops when the app quits,
 *   2. reads the tunnel's "RSD Address / RSD Port" from a log file in ~/Library/Logs/FakeGeo,
 *   3. runs the RSD handshake + the RSDCheckin + DTX LocationSimulation (the app's own code) over normal sockets.
 */
object WifiTunnel {
    class Outcome(val report: String, val fatal: Boolean)
    private class Fatal(msg: String) : Exception(msg)

    private val tunnelLog get() = File(FileLog.dir, "wifi-tunnel.log")
    private val stopFile get() = File(FileLog.dir, "wifi-tunnel.stop")
    private val skipFile get() = File(FileLog.dir, "wifi-tunnel.skip")
    private val pidFile get() = File(FileLog.dir, "wifi-tunnel.pid")

    private val addrRe = Regex("""RSD Address:\s*([0-9A-Fa-f:.]+(?:%\w+)?)""")
    private val portRe = Regex("""RSD Port:\s*(\d+)""")
    private val ansiRe = Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]")

    private val isMac = System.getProperty("os.name").lowercase().contains("mac")

    /** This app launch has started a supervisor (so its pid file can be trusted). */
    @Volatile private var started = false
    @Volatile private var hookAdded = false
    /** Does dtservicehub need the "RSDCheckin" message first? null = not learned yet. */
    @Volatile private var needsCheckin: Boolean? = null
    @Volatile private var binCache: String? = null

    // ------------------------------------------------------------------ a socket as the Stream the RSD/DTX code expects

    private class SockStream(private val s: Socket) : UsbMux.Stream {
        private val q = LinkedBlockingQueue<ByteArray>()
        @Volatile private var dead: String? = null
        private var rbuf = ByteArray(0)

        init {
            s.tcpNoDelay = true
            try { s.keepAlive = true } catch (_: Exception) {}
            Thread {
                try {
                    val inp = s.getInputStream()
                    val buf = ByteArray(65536)
                    while (true) { val n = inp.read(buf); if (n < 0) break; q.put(buf.copyOf(n)) }
                    dead = "connection closed by the iPhone"
                } catch (e: Exception) { dead = e.message ?: "connection closed" }
                q.put(ByteArray(0))
            }.also { it.isDaemon = true }.start()
        }

        private fun fill(deadline: Long) {
            val left = deadline - SystemClock.elapsedRealtime()
            if (left <= 0) throw IOException("timeout waiting for the iPhone")
            val b = q.poll(left, TimeUnit.MILLISECONDS) ?: throw IOException("timeout waiting for the iPhone")
            if (b.isEmpty()) { q.put(b); throw IOException(dead ?: "connection closed by the iPhone") }
            rbuf += b
        }

        @Synchronized override fun write(data: ByteArray) { val o = s.getOutputStream(); o.write(data); o.flush() }

        override fun read(n: Int, timeoutMs: Int): ByteArray {
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (rbuf.size < n) fill(end)
            val out = rbuf.copyOfRange(0, n); rbuf = rbuf.copyOfRange(n, rbuf.size); return out
        }

        override fun readSome(timeoutMs: Int): ByteArray {
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (rbuf.isEmpty()) fill(end)
            val out = rbuf; rbuf = ByteArray(0); return out
        }

        override fun close() { try { s.close() } catch (_: Exception) {} }
    }

    // ------------------------------------------------------------------ small helpers

    private fun alive(host: String, port: Int): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(InetAddress.getByName(host), port), 2000) }
        true
    } catch (_: Exception) { false }

    /** Shell-quote: 'text' with every ' turned into '\'' (works for any path, also with spaces). */
    private fun shq(s: String) = "'" + s.replace("'", "'\\''") + "'"

    /** Escape text for an AppleScript string literal. */
    private fun asq(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")

    /** Runs a command, returns its output; never waits longer than [seconds] (a hanging shell cannot freeze the app). */
    private fun capture(cmd: List<String>, seconds: Long): String {
        val out = StringBuffer()
        try {
            val pr = ProcessBuilder(cmd).redirectErrorStream(true).start()
            val t = Thread { try { pr.inputStream.bufferedReader().forEachLine { out.append(it).append('\n') } } catch (_: Exception) {} }
            t.isDaemon = true; t.start()
            if (!pr.waitFor(seconds, TimeUnit.SECONDS)) pr.destroyForcibly()
            t.join(500)
        } catch (_: Exception) {}
        return out.toString()
    }

    private fun readTunnelLog(): String = try { ansiRe.replace(tunnelLog.readText(), "") } catch (_: Exception) { "" }

    private fun tailOf(text: String, n: Int): String =
        text.trim().lines().filter { it.isNotBlank() }.takeLast(n).joinToString(" | ") { it.trim().take(200) }

    private fun endpointFrom(text: String): Pair<String, Int>? {
        val a = addrRe.findAll(text).lastOrNull() ?: return null
        val pt = portRe.findAll(text).lastOrNull { it.range.first > a.range.first } ?: return null
        val port = pt.groupValues[1].toIntOrNull() ?: return null
        return a.groupValues[1] to port
    }

    /** Finds the pymobiledevice3 program (also when the app was started from Finder, with a short PATH). */
    fun locate(): String? {
        binCache?.let { if (File(it).canExecute()) return it }
        val home = System.getProperty("user.home") ?: ""
        val cands = LinkedHashSet<String>()
        capture(listOf("/bin/zsh", "-lc", "command -v pymobiledevice3"), 6).trim().lines()
            .lastOrNull { it.trim().startsWith("/") }?.let { cands.add(it.trim()) }
        cands.add("/opt/homebrew/bin/pymobiledevice3")
        cands.add("/usr/local/bin/pymobiledevice3")
        cands.add("$home/.local/bin/pymobiledevice3")                                   // pipx
        cands.add("$home/.local/pipx/venvs/pymobiledevice3/bin/pymobiledevice3")
        cands.add("$home/.pyenv/shims/pymobiledevice3")
        cands.add("$home/miniconda3/bin/pymobiledevice3"); cands.add("$home/anaconda3/bin/pymobiledevice3")
        File("/Library/Frameworks/Python.framework/Versions").listFiles()?.sortedByDescending { it.name }
            ?.forEach { cands.add("${it.path}/bin/pymobiledevice3") }
        File("$home/Library/Python").listFiles()?.sortedByDescending { it.name }
            ?.forEach { cands.add("${it.path}/bin/pymobiledevice3") }
        val found = cands.firstOrNull { File(it).canExecute() }
        binCache = found
        return found
    }

    private fun supervisorRunning(): Boolean {
        if (!started) return false
        val pid = try { pidFile.readText().trim().toLong() } catch (_: Exception) { return false }
        return ProcessHandle.of(pid).map { it.isAlive }.orElse(false)
    }

    private fun stopSupervisor() {
        try { stopFile.writeText("1") } catch (_: Exception) {}
        started = false
    }

    // ------------------------------------------------------------------ the root supervisor

    private fun startSupervisor(bin: String, p: (String) -> Unit) {
        val home = System.getProperty("user.home") ?: throw Fatal("Cannot find your home folder.")
        FileLog.dir.mkdirs()
        stopFile.delete(); skipFile.delete(); pidFile.delete()
        try {
            val f = tunnelLog
            f.writeText("")
            f.setReadable(false, false); f.setReadable(true, true); f.setWritable(false, false); f.setWritable(true, true)
        } catch (_: Exception) {}

        val app = ProcessHandle.current().pid()
        val stop = shq(stopFile.path)
        val skip = shq(skipFile.path)
        val b = shq(bin)
        // Plain /bin/sh. Tries "lockdown start-tunnel" first, then "remote start-tunnel -t wifi", and starts over
        // whenever a tunnel ends. Everything stops when this app quits or the stop file appears.
        val script =
            "echo \$\$ > ${shq(pidFile.path)}; " +
            "export PYTHONUNBUFFERED=1 HOME=${shq(home)}; " +
            "alive() { kill -0 $app 2>/dev/null && [ ! -e $stop ]; }; " +
            "run() { \"\$@\" & P=\$!; " +
                "while kill -0 \$P 2>/dev/null && alive && [ ! -e $skip ]; do sleep 1; done; " +
                "kill \$P 2>/dev/null; sleep 1; kill -0 \$P 2>/dev/null && kill -9 \$P 2>/dev/null; " +
                "wait \$P 2>/dev/null; rm -f $skip; }; " +
            "while alive; do " +
                "echo '[fakegeo] start: lockdown start-tunnel'; run $b lockdown start-tunnel; " +
                "alive || break; sleep 2; " +
                "echo '[fakegeo] start: remote start-tunnel -t wifi'; run $b remote start-tunnel -t wifi; " +
                "sleep 3; " +
            "done"
        val cmd = "nohup /bin/sh -c ${shq(script)} >> ${shq(tunnelLog.path)} 2>&1 < /dev/null &"
        val osa = "do shell script \"" + asq(cmd) + "\" with administrator privileges"

        p("Starting the Wi-Fi tunnel with $bin")
        p("macOS now asks for your Mac password (once per app launch).")
        val pr = ProcessBuilder("/usr/bin/osascript", "-e", osa).redirectErrorStream(true).start()
        val outBuf = StringBuffer()
        val rt = Thread { try { pr.inputStream.bufferedReader().forEachLine { outBuf.append(it).append(' ') } } catch (_: Exception) {} }
        rt.isDaemon = true; rt.start()
        if (!pr.waitFor(180, TimeUnit.SECONDS)) { pr.destroyForcibly(); throw Fatal("Timed out waiting for the macOS password prompt.") }
        rt.join(500)
        if (pr.exitValue() != 0) {
            throw Fatal("The tunnel was not started (${outBuf.toString().trim().take(140)}). Was the password prompt cancelled?")
        }
        started = true
        if (!hookAdded) {
            hookAdded = true
            Runtime.getRuntime().addShutdownHook(Thread { try { stopFile.writeText("1") } catch (_: Exception) {} })
        }
    }

    /** Waits until the supervisor has published a tunnel that really accepts connections. */
    private fun waitForEndpoint(p: (String) -> Unit, totalMs: Long): Pair<String, Int> {
        val start = SystemClock.elapsedRealtime()
        var skipped = false
        var lastNote = start
        var unreachable = ""
        while (true) {
            val text = readTunnelLog()
            val ep = endpointFrom(text)
            if (ep != null) {
                if (alive(ep.first, ep.second)) return ep
                unreachable = "[${ep.first}]:${ep.second} is announced but does not accept connections yet"
            }
            val now = SystemClock.elapsedRealtime()
            val waited = now - start
            if (!skipped && waited > 35_000) {
                p("The first tunnel type did not come up in 35 s: trying the other one.")
                try { skipFile.writeText("1") } catch (_: Exception) {}
                skipped = true
            }
            if (now - lastNote > 10_000) {
                lastNote = now
                p("Waiting for the tunnel… ${(waited / 1000)} s. " + (if (unreachable.isNotEmpty()) "$unreachable. " else "") + "Tunnel log: " + tailOf(text, 2))
            }
            if (waited > totalMs) {
                val tail = tailOf(text, 4)
                stopSupervisor()
                throw Fatal(
                    "The Wi-Fi tunnel did not start. Tunnel log: $tail  |  Check: iPhone unlocked with the screen on, same Wi-Fi as the Mac, " +
                        "Developer Mode on, and 'Turn on Wi-Fi for this iPhone' done once with the cable. Full log: ${FileLog.file.path}"
                )
            }
            if (IosSession.stopRequested()) throw Fatal("Stopped.")
            Thread.sleep(700)
        }
    }

    private fun ensureTunnel(p: (String) -> Unit): Pair<String, Int> {
        // 1) a tunnel is already up (the supervisor keeps it alive): use it, no password needed
        endpointFrom(readTunnelLog())?.let { ep ->
            if (supervisorRunning() && alive(ep.first, ep.second)) { p("Using the running Wi-Fi tunnel [${ep.first}]:${ep.second}"); return ep }
        }
        // 2) the supervisor runs but the tunnel is down: it restarts it by itself, just wait
        if (supervisorRunning()) {
            p("The tunnel dropped. The tunnel helper is restarting it…")
            return waitForEndpoint(p, 75_000).also { p("Tunnel is up: [${it.first}]:${it.second}") }
        }
        // 3) first start in this app launch
        val bin = locate()
            ?: throw Fatal("pymobiledevice3 was not found. Install it once in Terminal:  pip3 install -U pymobiledevice3   (then press the button again)")
        val ver = capture(listOf(bin, "version"), 10).trim().lines().lastOrNull { it.isNotBlank() }?.take(60) ?: ""
        if (ver.isNotEmpty()) p("pymobiledevice3 version: $ver")
        startSupervisor(bin, p)
        return waitForEndpoint(p, 75_000).also { p("Tunnel is up: [${it.first}]:${it.second}") }
    }

    // ------------------------------------------------------------------ connect, handshake, location

    private fun hintFor(msg: String, p: (String) -> Unit) {
        if (msg.contains("No route to host", true) || msg.contains("Operation not permitted", true) || msg.contains("Network is unreachable", true))
            p("Hint: macOS may be blocking this app from the local network. Open System Settings > Privacy & Security > Local Network " +
                "and switch FakeGeo ON (if you start it with 'gradle run', switch on Terminal / your IDE instead), then try again.")
    }

    private fun openSock(addr: InetAddress, port: Int, p: (String) -> Unit): SockStream {
        var last: Exception? = null
        for (i in 1..3) {
            val s = Socket()
            try {
                s.connect(InetSocketAddress(addr, port), 6000)
                return SockStream(s)
            } catch (e: Exception) {
                last = e
                try { s.close() } catch (_: Exception) {}
                p("connect to [${addr.hostAddress}]:$port failed (try $i/3): ${e.message}")
                if (i < 3) Thread.sleep(1000)
            }
        }
        hintFor(last?.message ?: "", p)
        throw IOException("could not connect to [${addr.hostAddress}]:$port: ${last?.message}")
    }

    /** Opens dtservicehub and runs the live location loop. Learns whether the "RSDCheckin" message is needed. */
    private fun runDtx(addr: InetAddress, hub: Int, rsd: Rsd.Result, p: (String) -> Unit): Boolean {
        val modes = when (needsCheckin) { true -> listOf(true); false -> listOf(false); null -> listOf(true, false) }
        var normal = false
        for (useCheckin in modes) {
            Dtx.liveOpened = false
            p("Connecting to dtservicehub (port $hub)" + if (useCheckin) " with RSDCheckin…" else " without RSDCheckin…")
            val d = openSock(addr, hub, p)
            try {
                if (useCheckin && !Rsd.checkin(d, p)) {
                    if (needsCheckin == null) continue          // learn: try the other way
                    return false
                }
                normal = Dtx.live(d, { _ -> rsd.keepAlive(1) }, p)
                if (Dtx.liveOpened) { needsCheckin = useCheckin; return normal }
                // the channel never opened: try the other way, if there is one
            } catch (e: IOException) {
                p("DTX error: ${e.message}")
                if (Dtx.liveOpened) { needsCheckin = useCheckin; return false }
            } finally { d.close() }
        }
        return normal
    }

    fun run(): Outcome {
        val sb = StringBuilder()
        fun p(s: String) { sb.appendLine(s); MockState.log("iOS Wi-Fi: $s") }
        if (!isMac) return Outcome("Wi-Fi mode works on macOS only.", true)
        try {
            val (host, port) = ensureTunnel(::p)
            val addr = InetAddress.getByName(host)
            p("Connecting to the iPhone (RSD) [$host]:$port …")
            val c = openSock(addr, port, ::p)
            try {
                val rsd = Rsd.handshake(c, ::p)
                val info = rsd?.info
                if (rsd == null || info == null) { p("RSD handshake failed."); return Outcome(sb.toString(), false) }
                val hub = ((info["Services"] as? Map<*, *>)?.get("com.apple.instruments.dtservicehub") as? Map<*, *>)
                    ?.get("Port")?.toString()?.toIntOrNull()
                if (hub == null) { p("The iPhone does not offer dtservicehub. Is Developer Mode on and the disk image mounted?"); return Outcome(sb.toString(), false) }
                val normal = runDtx(addr, hub, rsd, ::p)
                p(if (normal) "Live session ended normally." else "Live session broke; it will reconnect.")
            } finally { c.close() }
        } catch (e: Fatal) {
            p(e.message ?: "Wi-Fi tunnel error")
            return Outcome(sb.toString(), true)
        } catch (e: Exception) {
            p("ERROR: ${e.javaClass.simpleName}: ${e.message}")
            hintFor(e.message ?: "", ::p)
        }
        return Outcome(sb.toString(), false)
    }
}
