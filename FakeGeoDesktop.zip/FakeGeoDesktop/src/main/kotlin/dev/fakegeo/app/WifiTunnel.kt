package dev.fakegeo.app

import java.io.File
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Wi-Fi mode (macOS). Our own lockdown-service connection is closed by the iPhone over Wi-Fi, but the
 * pymobiledevice3 tool ("lockdown start-tunnel") is proven to work on the same iPhone over Wi-Fi.
 * So: start that tunnel (one macOS password prompt; it stops by itself when this app quits), then run the
 * RSD handshake + DTX LocationSimulation (the code that already works over USB) through ordinary sockets.
 */
object WifiTunnel {
    class Outcome(val report: String, val fatal: Boolean)
    private class Fatal(msg: String) : Exception(msg)

    private const val LOG = "/tmp/fakegeo_tunnel.log"
    private val safe = Regex("^[A-Za-z0-9_./+@-]+$")
    private val addrRe = Regex("""RSD Address:\s*(\S+)""")
    private val portRe = Regex("""RSD Port:\s*(\d+)""")
    @Volatile private var rsdHost: String? = null
    @Volatile private var rsdPort = 0

    /** A normal TCP socket as the Stream the RSD/DTX code expects (same behaviour as the usbmux pipe). */
    private class SockStream(private val s: Socket) : UsbMux.Stream {
        private val q = LinkedBlockingQueue<ByteArray>()
        @Volatile private var dead: String? = null
        private var rbuf = ByteArray(0)

        init {
            s.tcpNoDelay = true
            Thread {
                try {
                    val inp = s.getInputStream()
                    val buf = ByteArray(65536)
                    while (true) { val n = inp.read(buf); if (n < 0) break; q.put(buf.copyOf(n)) }
                    dead = "connection closed by the iPhone"
                } catch (e: Exception) { dead = e.message ?: "connection closed" }
                q.put(ByteArray(0))
            }.also { it.isDaemon = true }.start()
        }

        private fun fill(deadline: Long) {
            val left = deadline - SystemClock.elapsedRealtime()
            if (left <= 0) throw IOException("timeout waiting for the iPhone")
            val b = q.poll(left, TimeUnit.MILLISECONDS) ?: throw IOException("timeout waiting for the iPhone")
            if (b.isEmpty()) { q.put(b); throw IOException(dead ?: "connection closed by the iPhone") }
            rbuf += b
        }

        @Synchronized override fun write(data: ByteArray) { val o = s.getOutputStream(); o.write(data); o.flush() }

        override fun read(n: Int, timeoutMs: Int): ByteArray {
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (rbuf.size < n) fill(end)
            val out = rbuf.copyOfRange(0, n); rbuf = rbuf.copyOfRange(n, rbuf.size); return out
        }

        override fun readSome(timeoutMs: Int): ByteArray {
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (rbuf.isEmpty()) fill(end)
            val out = rbuf; rbuf = ByteArray(0); return out
        }

        override fun close() { try { s.close() } catch (_: Exception) {} }
    }

    private fun alive(host: String, port: Int): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(InetAddress.getByName(host), port), 2000) }
        true
    } catch (_: Exception) { false }

    private fun findBinary(): String? {
        val home = System.getProperty("user.home") ?: ""
        val cands = ArrayList<String>()
        try {
            val pr = ProcessBuilder("/bin/zsh", "-lc", "command -v pymobiledevice3").redirectErrorStream(true).start()
            val out = pr.inputStream.bufferedReader().readText().trim().lines().lastOrNull() ?: ""
            pr.waitFor(5, TimeUnit.SECONDS)
            if (out.startsWith("/")) cands.add(out)
        } catch (_: Exception) {}
        cands.add("/opt/homebrew/bin/pymobiledevice3")
        cands.add("/usr/local/bin/pymobiledevice3")
        File("/Library/Frameworks/Python.framework/Versions").listFiles()?.sortedByDescending { it.name }
            ?.forEach { cands.add("${it.path}/bin/pymobiledevice3") }
        File("$home/Library/Python").listFiles()?.forEach { cands.add("${it.path}/bin/pymobiledevice3") }
        return cands.firstOrNull { File(it).canExecute() && safe.matches(it) }
    }

    /** Starts "lockdown start-tunnel" as root (macOS password prompt) and returns the tunnel's RSD address and port. */
    private fun startTunnel(bin: String, p: (String) -> Unit): Pair<String, Int> {
        val home = System.getProperty("user.home") ?: "/var/root"
        if (!safe.matches(home)) throw Fatal("Unsupported home folder path: $home")
        val pid = ProcessHandle.current().pid()
        // The tunnel stops by itself when this app quits (the loop watches this app's process id).
        val inner = "PYTHONUNBUFFERED=1 HOME=$home \"$bin\" lockdown start-tunnel & P=\$!; " +
            "while kill -0 $pid 2>/dev/null; do sleep 2; done; kill \$P"
        val cmd = "rm -f $LOG; nohup /bin/sh -c '$inner' > $LOG 2>&1 < /dev/null &"
        val script = "do shell script \"" + cmd.replace("\\", "\\\\").replace("\"", "\\\"") + "\" with administrator privileges"
        p("Starting the Wi-Fi tunnel ($bin). Enter your Mac password when macOS asks.")
        val pr = ProcessBuilder("/usr/bin/osascript", "-e", script).redirectErrorStream(true).start()
        if (!pr.waitFor(180, TimeUnit.SECONDS)) { pr.destroy(); throw Fatal("Timed out waiting for the macOS password prompt.") }
        if (pr.exitValue() != 0) {
            val msg = pr.inputStream.bufferedReader().readText().trim()
            throw Fatal("The tunnel was not started (${msg.take(120)}). Was the password prompt cancelled?")
        }
        val end = SystemClock.elapsedRealtime() + 45_000
        var text = ""
        while (SystemClock.elapsedRealtime() < end) {
            Thread.sleep(500)
            text = try { File(LOG).readText() } catch (_: Exception) { "" }
            val a = addrRe.find(text)
            val pt = portRe.find(text)
            if (a != null && pt != null) return a.groupValues[1] to pt.groupValues[1].toInt()
            if (text.contains("ERROR") || text.contains("Traceback")) break
        }
        val tail = text.trim().lines().takeLast(4).joinToString(" | ")
        throw Fatal("The Wi-Fi tunnel did not start: $tail\nCheck: iPhone unlocked with the screen on, same Wi-Fi as the Mac, and 'Turn on Wi-Fi for this iPhone' done once with the cable.")
    }

    private fun ensureTunnel(p: (String) -> Unit): Pair<String, Int> {
        val h = rsdHost
        if (h != null && alive(h, rsdPort)) { p("Using the running Wi-Fi tunnel."); return h to rsdPort }
        rsdHost = null
        val bin = findBinary()
            ?: throw Fatal("pymobiledevice3 was not found. Install it once in Terminal:  pip3 install -U pymobiledevice3")
        val t = startTunnel(bin, p)
        rsdHost = t.first; rsdPort = t.second
        p("Tunnel is up: [${t.first}]:${t.second}")
        return t
    }

    fun run(): Outcome {
        val sb = StringBuilder()
        fun p(s: String) { sb.appendLine(s); MockState.log("iOS Wi-Fi: $s") }
        if (!System.getProperty("os.name").lowercase().contains("mac"))
            return Outcome("Wi-Fi mode works on macOS only.", true)
        try {
            val (host, port) = ensureTunnel(::p)
            val addr = InetAddress.getByName(host)
            p("Connecting to the iPhone (RSD) [$host]:$port …")
            val rsdSock = Socket()
            try { rsdSock.connect(InetSocketAddress(addr, port), 6000) } catch (e: Exception) { rsdHost = null; throw e }
            val c = SockStream(rsdSock)
            try {
                val rsd = Rsd.handshake(c, ::p)
                val info = rsd?.info
                if (rsd == null || info == null) { p("RSD handshake failed."); return Outcome(sb.toString(), false) }
                val hub = ((info["Services"] as? Map<*, *>)?.get("com.apple.instruments.dtservicehub") as? Map<*, *>)
                    ?.get("Port")?.toString()?.toIntOrNull()
                if (hub == null) { p("The iPhone does not offer dtservicehub. Is the disk image mounted?"); return Outcome(sb.toString(), false) }
                p("Connecting to dtservicehub (port $hub)…")
                val dSock = Socket()
                dSock.connect(InetSocketAddress(addr, hub), 6000)
                val d = SockStream(dSock)
                try {
                    val normal = Dtx.live(d, { _ -> rsd.keepAlive(1) }, ::p)
                    p(if (normal) "Live session ended normally." else "Live session broke; it will reconnect.")
                } catch (e: IOException) {
                    p("DTX error: ${e.message}")
                } finally { d.close() }
            } finally { c.close() }
        } catch (e: Fatal) {
            p(e.message ?: "Wi-Fi tunnel error")
            return Outcome(sb.toString(), true)
        } catch (e: Exception) {
            p("ERROR: ${e.javaClass.simpleName}: ${e.message}")
        }
        return Outcome(sb.toString(), false)
    }
}
