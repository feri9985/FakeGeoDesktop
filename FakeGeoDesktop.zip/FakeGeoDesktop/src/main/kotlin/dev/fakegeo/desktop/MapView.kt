package dev.fakegeo.desktop

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toComposeImageBitmap
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.onPointerEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.*

data class LatLon(val lat: Double, val lon: Double)

/** State of the map that the rest of the UI can also move (search results, "my pin"). */
class MapState(lat: Double, lon: Double, zoom: Int) {
    var lat by mutableStateOf(lat)
    var lon by mutableStateOf(lon)
    var zoom by mutableStateOf(zoom)
    var pin by mutableStateOf<LatLon?>(null)
    var active by mutableStateOf<LatLon?>(null)   // where the iPhone is being sent right now
    fun flyTo(la: Double, lo: Double, z: Int = 15) { lat = la; lon = lo; zoom = z }
}

private object Tiles {
    val cache = ConcurrentHashMap<String, ImageBitmap>()
    private val pending = ConcurrentHashMap.newKeySet<String>()
    private val pool = Executors.newFixedThreadPool(12) { r -> Thread(r).also { it.isDaemon = true } }
    private val dir = java.io.File(System.getProperty("user.home"), ".fakegeo/tiles")
    // One shared HTTP/2 client: connections are reused, so tiles do not each pay a new TLS handshake.
    private val http: java.net.http.HttpClient by lazy {
        java.net.http.HttpClient.newBuilder().version(java.net.http.HttpClient.Version.HTTP_2)
            .connectTimeout(java.time.Duration.ofSeconds(8)).build()
    }
    var version by mutableStateOf(0)

    /** Already-loaded tile, or null (and starts loading it). */
    fun get(z: Int, x: Int, y: Int): ImageBitmap? {
        val key = "$z/$x/$y"
        cache[key]?.let { return it }
        if (pending.add(key)) pool.execute {
            try {
                val f = java.io.File(dir, "$key.png")
                val bytes = if (f.exists() && f.length() > 0) f.readBytes() else {
                    val req = java.net.http.HttpRequest.newBuilder(java.net.URI("https://tile.openstreetmap.org/$key.png"))
                        .header("User-Agent", "FakeGeoDesktop/1.0 (personal use)").timeout(java.time.Duration.ofSeconds(10)).build()
                    val r = http.send(req, java.net.http.HttpResponse.BodyHandlers.ofByteArray())
                    if (r.statusCode() != 200) throw java.io.IOException("HTTP ${r.statusCode()}")
                    f.parentFile.mkdirs(); f.writeBytes(r.body()); r.body()
                }
                cache[key] = org.jetbrains.skia.Image.makeFromEncoded(bytes).toComposeImageBitmap()
                version++
            } catch (_: Exception) {
            } finally { pending.remove(key) }
        }
        return null
    }

    /** Cache hit only (never starts a download). */
    fun peek(z: Int, x: Int, y: Int): ImageBitmap? = cache["$z/$x/$y"]
}

private fun worldX(lon: Double, z: Int, ts: Double) = (lon + 180.0) / 360.0 * (1 shl z) * ts
private fun worldY(lat: Double, z: Int, ts: Double): Double {
    val r = Math.toRadians(lat.coerceIn(-85.0511, 85.0511))
    return (1.0 - ln(tan(r) + 1.0 / cos(r)) / PI) / 2.0 * (1 shl z) * ts
}
private fun lonOf(x: Double, z: Int, ts: Double) = x / ((1 shl z) * ts) * 360.0 - 180.0
private fun latOf(y: Double, z: Int, ts: Double): Double {
    val n = PI - 2.0 * PI * y / ((1 shl z) * ts)
    return Math.toDegrees(atan(sinh(n)))
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun MapView(state: MapState, modifier: Modifier = Modifier, onPick: (LatLon) -> Unit) {
    val density = LocalDensity.current.density
    val ts = 256.0 * density
    var size by remember { mutableStateOf(IntSize(1, 1)) }
    @Suppress("UNUSED_VARIABLE") val v = Tiles.version   // re-draw when a tile arrives

    Box(modifier.onSizeChanged { size = it }) {
        Canvas(
            Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        val cx = worldX(state.lon, state.zoom, ts) - drag.x
                        val cy = worldY(state.lat, state.zoom, ts) - drag.y
                        state.lon = lonOf(cx, state.zoom, ts).coerceIn(-180.0, 180.0)
                        state.lat = latOf(cy, state.zoom, ts).coerceIn(-85.0, 85.0)
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { p ->
                        val wx = worldX(state.lon, state.zoom, ts) - size.width / 2.0 + p.x
                        val wy = worldY(state.lat, state.zoom, ts) - size.height / 2.0 + p.y
                        val ll = LatLon(latOf(wy, state.zoom, ts), lonOf(wx, state.zoom, ts))
                        state.pin = ll; onPick(ll)
                    }
                }
                .onPointerEvent(PointerEventType.Scroll) { e ->
                    val dy = e.changes.firstOrNull()?.scrollDelta?.y ?: 0f
                    if (dy < 0) state.zoom = (state.zoom + 1).coerceAtMost(19)
                    else if (dy > 0) state.zoom = (state.zoom - 1).coerceAtLeast(2)
                }
        ) {
            val z = state.zoom
            val left = worldX(state.lon, z, ts) - size.width / 2.0
            val top = worldY(state.lat, z, ts) - size.height / 2.0
            drawRect(Color(0xFFDDE3EA))
            val n = 1 shl z
            for (tx in floor(left / ts).toInt()..floor((left + size.width) / ts).toInt()) {
                for (ty in floor(top / ts).toInt()..floor((top + size.height) / ts).toInt()) {
                    if (ty < 0 || ty >= n) continue
                    val wx = ((tx % n) + n) % n
                    val dst = IntOffset((tx * ts - left).roundToInt(), (ty * ts - top).roundToInt())
                    val dsz = IntSize(ceil(ts).toInt() + 1, ceil(ts).toInt() + 1)
                    val img = Tiles.get(z, wx, ty)
                    if (img != null) { drawImage(img, dstOffset = dst, dstSize = dsz); continue }
                    // blurry stand-in from a parent tile (up to 4 levels up) until the sharp one arrives
                    for (up in 1..4) {
                        if (z - up < 0) break
                        val par = Tiles.peek(z - up, wx shr up, ty shr up) ?: continue
                        val cell = par.width / (1 shl up)
                        drawImage(
                            par, srcOffset = IntOffset((wx and ((1 shl up) - 1)) * cell, (ty and ((1 shl up) - 1)) * cell),
                            srcSize = IntSize(cell, cell), dstOffset = dst, dstSize = dsz
                        )
                        break
                    }
                }
            }
            fun at(l: LatLon) = Offset((worldX(l.lon, z, ts) - left).toFloat(), (worldY(l.lat, z, ts) - top).toFloat())
            state.active?.let { a ->   // blue dot = where the iPhone is now
                val o = at(a)
                drawCircle(Color(0x222F6BFF), 30f * density, o)
                drawCircle(Color(0x442F6BFF), 18f * density, o)
                drawCircle(Color.White, 9f * density, o)
                drawCircle(Color(0xFF2F6BFF), 6.5f * density, o)
            }
            state.pin?.let { p ->          // map pin: soft shadow, gradient body, glossy highlight
                val o = at(p); val s = density
                drawOval(Color(0x44000000), Offset(o.x - 9 * s, o.y - 3 * s), androidx.compose.ui.geometry.Size(18 * s, 6 * s))
                val path = Path().apply {
                    moveTo(o.x, o.y)
                    cubicTo(o.x - 8 * s, o.y - 12 * s, o.x - 19 * s, o.y - 22 * s, o.x - 19 * s, o.y - 35 * s)
                    cubicTo(o.x - 19 * s, o.y - 47 * s, o.x - 10 * s, o.y - 56 * s, o.x, o.y - 56 * s)
                    cubicTo(o.x + 10 * s, o.y - 56 * s, o.x + 19 * s, o.y - 47 * s, o.x + 19 * s, o.y - 35 * s)
                    cubicTo(o.x + 19 * s, o.y - 22 * s, o.x + 8 * s, o.y - 12 * s, o.x, o.y)
                    close()
                }
                drawPath(path, androidx.compose.ui.graphics.Brush.linearGradient(
                    listOf(Color(0xFFFF6B5E), Color(0xFFD7261B)), Offset(o.x - 19 * s, o.y - 56 * s), Offset(o.x + 19 * s, o.y)))
                drawPath(path, Color(0xFF9E1B12), style = Stroke(1.6f * s))
                drawCircle(Color.White, 8.5f * s, Offset(o.x, o.y - 36 * s))
                drawCircle(Color(0xFFB71C12), 3.6f * s, Offset(o.x, o.y - 36 * s))
                drawArc(Color(0x55FFFFFF), 200f, 70f, false, Offset(o.x - 14 * s, o.y - 51 * s),
                    androidx.compose.ui.geometry.Size(28 * s, 28 * s), style = Stroke(3f * s))
            }
        }
        Column(Modifier.align(Alignment.BottomEnd).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((label, d) in listOf("+" to 1, "−" to -1)) {
                Button(
                    onClick = { state.zoom = (state.zoom + d).coerceIn(2, 19) },
                    modifier = Modifier.size(38.dp).clip(CircleShape),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF222222))
                ) { Text(label) }
            }
        }
        Text(
            "© OpenStreetMap contributors",
            color = Color(0xFF444444), modifier = Modifier.align(Alignment.BottomStart).padding(6.dp),
            style = androidx.compose.ui.text.TextStyle(fontSize = androidx.compose.ui.unit.TextUnit(10f, androidx.compose.ui.unit.TextUnitType.Sp))
        )
    }
}
