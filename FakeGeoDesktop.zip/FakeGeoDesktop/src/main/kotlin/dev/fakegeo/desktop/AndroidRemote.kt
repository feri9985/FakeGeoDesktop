package dev.fakegeo.desktop

import dev.fakegeo.app.FileLog
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit

/**
 * One connection to the remote-control server of the FakeGeo Android app on ONE phone (one JSON object per line).
 * Over USB the phone is reached through "adb forward" (host 127.0.0.1, its own local port); over Wi-Fi by its IP.
 */
class AndroidLink(val key: String, @Volatile var label: String, val host: String, val port: Int, val pin: String) {
    /** The connection to the phone is open. */
    @Volatile var connected = false
    /** A position was sent and not stopped: the phone shows the fake location. */
    @Volatile var sending = false
    @Volatile var message = ""
    private var sock: Socket? = null
    private var rd: BufferedReader? = null

    @Synchronized fun disconnect() {
        try { sock?.close() } catch (_: Exception) {}
        sock = null; rd = null; connected = false; sending = false
    }

    @Synchronized private fun call(req: JSONObject): JSONObject {
        val s = sock ?: throw java.io.IOException("not connected")
        s.getOutputStream().write((req.toString() + "\n").toByteArray()); s.getOutputStream().flush()
        val line = rd!!.readLine() ?: throw java.io.IOException("the phone closed the connection")
        return JSONObject(line)
    }

    /** Like [call], but when the connection was lost (phone slept, Wi-Fi blip) it reconnects once and repeats the request. */
    @Synchronized private fun callRetry(req: JSONObject): JSONObject = try { call(req) } catch (e: java.io.IOException) {
        FileLog.add("Android [$label]: connection lost (${e.message}); reconnecting to $host…")
        val err = connect()
        if (err != null) throw java.io.IOException(err)
        call(req)
    }

    /** Returns null on success, otherwise a message for the user. */
    @Synchronized fun connect(): String? {
        disconnect()
        return try {
            val s = Socket(); s.connect(InetSocketAddress(host, port), 4000); s.soTimeout = 8000; s.tcpNoDelay = true
            try { s.keepAlive = true } catch (_: Exception) {}
            sock = s; rd = BufferedReader(InputStreamReader(s.getInputStream()))
            val r = call(JSONObject().put("cmd", "hello").put("pin", pin))
            if (r.optBoolean("ok")) {
                connected = true; message = "Connected"
                // newer apps may tell their phone model
                val m = r.optString("model", "").ifBlank { r.optString("name", "") }
                if (m.isNotBlank()) label = m
                if (host != "127.0.0.1") AndroidRemote.rememberIp(host)
                FileLog.add("Android [$label]: connected to $host:$port")
                null
            } else { val e = r.optString("error", "refused"); disconnect(); message = e; e }
        } catch (e: Exception) {
            disconnect()
            FileLog.add("Android [$label]: cannot reach $host:$port: ${e.message}")
            message = "Cannot reach the phone: ${e.message}"
            message
        }
    }

    fun set(lat: Double, lon: Double): String? = try {
        val r = callRetry(JSONObject().put("cmd", "set").put("lat", lat).put("lon", lon))
        if (r.optBoolean("ok")) { connected = true; sending = true; message = "At %.5f, %.5f".format(java.util.Locale.US, lat, lon); null }
        else r.optString("error", "the phone refused").also { message = it }
    } catch (e: Exception) { connected = false; sending = false; ("Connection lost: ${e.message}").also { message = it } }

    fun stop(): String? = try {
        val r = callRetry(JSONObject().put("cmd", "stop"))
        sending = false
        if (r.optBoolean("ok")) { message = "Back on the real location"; null } else r.optString("error", "error").also { message = it }
    } catch (e: Exception) { connected = false; sending = false; ("Connection lost: ${e.message}").also { message = it } }
}

/** All Android phones connected in this app run. */
object AndroidHub {
    val links = CopyOnWriteArrayList<AndroidLink>()
    private val ports = HashMap<String, Int>()
    private var nextPort = 47400

    /** The local port that "adb forward" uses for one phone (the same one every time). */
    @Synchronized fun portFor(serial: String): Int = ports.getOrPut(serial) { nextPort++ }

    fun find(key: String): AndroidLink? = links.firstOrNull { it.key == key }
    fun add(l: AndroidLink) { remove(l.key); links.add(l) }
    fun remove(key: String) { for (l in links.filter { it.key == key }) { l.disconnect(); links.remove(l) } }
    fun connectedCount(): Int = links.count { it.connected }
}

/** Finding Android phones on the local network. */
object AndroidRemote {
    const val PORT = 47321

    /** Last message of the network search (the screen shows it when nothing was found). */
    @Volatile var diag = ""

    private val ipFile get() = File(System.getProperty("user.home") ?: ".", ".fakegeo/android_ips")
    fun knownIps(): List<String> = try { ipFile.readLines().map { it.trim() }.filter { it.isNotEmpty() } } catch (_: Exception) { emptyList() }
    fun rememberIp(ip: String) {
        try {
            val all = (listOf(ip) + knownIps()).distinct().take(8)
            ipFile.parentFile?.mkdirs(); ipFile.writeText(all.joinToString("\n") + "\n")
        } catch (_: Exception) {}
    }

    private fun probe(ip: String, timeoutMs: Int): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(ip, PORT), timeoutMs) }; true
    } catch (_: Exception) { false }

    private fun ipStr(h: Long) = "${(h shr 24) and 255}.${(h shr 16) and 255}.${(h shr 8) and 255}.${h and 255}"

    /**
     * Looks for FakeGeo phones on the local network and returns ALL their IPs (several phones can be on the same Wi-Fi).
     * Scans every interface of this Mac (its own /24 first, then the rest of the subnet up to a /22) and also tries the
     * addresses that worked before. [log] gets a readable summary, also when nothing was found.
     */
    fun discoverAll(log: (String) -> Unit = {}): List<String> {
        fun note(s: String) { diag = s; FileLog.add("Android scan: " + s.replace('\n', ' ')); log(s) }
        val found = ConcurrentLinkedQueue<String>()
        val targets = LinkedHashSet<String>()
        val ifs = ArrayList<String>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces().toList()) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name
                if (listOf("awdl", "llw", "utun", "docker", "vmnet", "vboxnet", "bridge").any { n.startsWith(it) }) continue
                for (ia in ni.interfaceAddresses) {
                    val a = ia.address as? Inet4Address ?: continue
                    if (a.isLinkLocalAddress || a.isAnyLocalAddress) continue
                    ifs.add("$n=${a.hostAddress}/${ia.networkPrefixLength}")
                    val ip = a.address.fold(0L) { acc, b -> (acc shl 8) or (b.toLong() and 0xFF) }
                    val b24 = ip and 0xFFFFFF00L
                    for (i in 1..254) { val h = b24 + i; if (h != ip) targets.add(ipStr(h)) }
                    val prefix = ia.networkPrefixLength.toInt()
                    if (prefix in 22..23) {
                        val mask = (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL
                        val base = ip and mask
                        for (i in 1..((1L shl (32 - prefix)) - 2)) { val h = base + i; if (h != ip) targets.add(ipStr(h)) }
                    }
                }
            }
        } catch (e: Exception) { note("Network list failed: ${e.message}") }
        if (targets.isEmpty()) {
            note("This Mac has no Wi-Fi/LAN address (IPv4). Join the same Wi-Fi as the phone. Interfaces: ${ifs.joinToString().ifEmpty { "none" }}")
            return emptyList()
        }
        note("Looking for phones (port $PORT) on ${targets.size} addresses… Mac interfaces: ${ifs.joinToString()}")

        val errs = ConcurrentHashMap<String, Int>()
        val pool = java.util.concurrent.Executors.newFixedThreadPool(128)
        for (t in targets) pool.execute {
            try { Socket().use { it.connect(InetSocketAddress(t, PORT), 800) }; found.add(t) }
            catch (e: Exception) { errs.merge(e.message ?: e.javaClass.simpleName, 1) { x, y -> x + y } }
        }
        pool.shutdown(); pool.awaitTermination(40, TimeUnit.SECONDS); pool.shutdownNow()
        // phones outside the scanned subnets that worked before
        for (ip in knownIps()) if (ip !in found && ip !in targets && probe(ip, 1500)) found.add(ip)

        val list = found.toList().distinct().sortedBy { ip -> ip.split('.').map { it.toIntOrNull() ?: 0 }.fold(0L) { a, b -> a * 256 + b } }
        if (list.isNotEmpty()) { note("Found ${list.size} phone(s): ${list.joinToString()}"); return list }

        val top = errs.entries.sortedByDescending { it.value }.take(3).joinToString { "${it.key} x${it.value}" }
        val blocked = errs.keys.any { it.contains("No route to host", true) || it.contains("Operation not permitted", true) }
        note(
            "No phone answered on port $PORT (scanned ${targets.size} addresses; $top).\n" +
                (if (blocked) "macOS may block this app from the local network: System Settings > Privacy & Security > Local Network > switch FakeGeo ON " +
                    "(started with 'gradle run'? switch on Terminal / your IDE).\n" else "") +
                "Check: the FakeGeo app is open on the phone with remote control ON, the phone screen is on, and both are on the same Wi-Fi " +
                "(guest / office Wi-Fi often isolates devices; a phone hotspot works)."
        )
        return emptyList()
    }
}

/** Finds and runs `adb` (Android platform-tools) for USB mode. */
object Adb {
    @Volatile private var cached: String? = null
    @Volatile private var lastSearch = 0L

    /** Cached: the screen asks every 2 seconds, and a missing adb is searched for at most every 10 seconds. */
    fun find(): String? {
        cached?.let { if (File(it).canExecute()) return it }
        val now = System.currentTimeMillis()
        if (now - lastSearch < 10_000) return null
        lastSearch = now
        cached = search()
        return cached
    }

    private fun search(): String? {
        val home = System.getProperty("user.home")
        val cands = listOf(
            "/opt/homebrew/bin/adb", "/usr/local/bin/adb", "$home/Library/Android/sdk/platform-tools/adb",
            "$home/Android/Sdk/platform-tools/adb", "C:\\Users\\${System.getProperty("user.name")}\\AppData\\Local\\Android\\Sdk\\platform-tools\\adb.exe"
        )
        cands.firstOrNull { File(it).canExecute() }?.let { return it }
        // the app started from Finder has a short PATH: ask a login shell
        return try { run(listOf("/bin/zsh", "-lc", "command -v adb")).trim().lines().lastOrNull { it.trim().startsWith("/") }?.trim() } catch (_: Exception) { null }
    }

    /** Output of a command; never waits more than ~10 s (the adb server it may start keeps the pipe open and used to hang this). */
    fun run(cmd: List<String>): String {
        val out = StringBuffer()
        val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
        val t = Thread { try { p.inputStream.bufferedReader().forEachLine { out.append(it).append('\n') } } catch (_: Exception) {} }
        t.isDaemon = true; t.start()
        if (!p.waitFor(10, TimeUnit.SECONDS)) p.destroyForcibly()
        t.join(1000)
        return out.toString()
    }

    /** serial -> state ("device", "unauthorized", ...) */
    fun devices(adb: String): List<Pair<String, String>> =
        run(listOf(adb, "devices")).lines().drop(1).mapNotNull {
            val t = it.trim().split(Regex("\\s+")); if (t.size >= 2) t[0] to t[1] else null
        }

    /** Phone port [remote] reachable on this Mac as 127.0.0.1:[local] (every phone needs its own [local]). */
    fun forward(adb: String, serial: String, local: Int, remote: Int): String? {
        val out = run(listOf(adb, "-s", serial, "forward", "tcp:$local", "tcp:$remote"))
        return if (out.contains("error", true)) out.trim() else null
    }

    private fun prop(adb: String, serial: String, name: String): String {
        val out = run(listOf(adb, "-s", serial, "shell", "getprop", name)).trim()
        if (out.contains("error", true) || out.contains("unauthorized", true) || out.contains("offline", true)) return ""
        return out.lines().lastOrNull { it.isNotBlank() }?.trim().orEmpty()
    }

    /** "Samsung Galaxy S23" / "Pixel 8": the phone's own market name (or model) with its maker. Talks to the phone: not on the screen thread. */
    fun title(adb: String, serial: String): String {
        val market = prop(adb, serial, "ro.product.marketname")
        val model = prop(adb, serial, "ro.product.model")
        val brand = prop(adb, serial, "ro.product.manufacturer")
        val name = market.ifBlank { model }
        if (name.isBlank()) return "Android phone"
        val b = brand.replaceFirstChar { it.uppercase() }
        return if (b.isNotBlank() && !name.startsWith(brand, true)) "$b $name" else name
    }
}
