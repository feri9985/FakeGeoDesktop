package dev.fakegeo.desktop

import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit

/** Talks to the FakeGeo Android app's remote-control server (one JSON object per line). */
object AndroidRemote {
    const val PORT = 47321
    private var sock: Socket? = null
    private var rd: BufferedReader? = null

    @Synchronized fun disconnect() { try { sock?.close() } catch (_: Exception) {}; sock = null; rd = null }

    @Synchronized private fun call(req: JSONObject): JSONObject {
        val s = sock ?: throw java.io.IOException("not connected")
        s.getOutputStream().write((req.toString() + "\n").toByteArray()); s.getOutputStream().flush()
        val line = rd!!.readLine() ?: throw java.io.IOException("the phone closed the connection")
        return JSONObject(line)
    }

    /** Returns null on success, otherwise a message for the user. */
    @Synchronized fun connect(host: String, port: Int, pin: String): String? {
        disconnect()
        return try {
            val s = Socket(); s.connect(InetSocketAddress(host, port), 4000); s.soTimeout = 8000; s.tcpNoDelay = true
            sock = s; rd = BufferedReader(InputStreamReader(s.getInputStream()))
            val r = call(JSONObject().put("cmd", "hello").put("pin", pin))
            if (r.optBoolean("ok")) null else { disconnect(); r.optString("error", "refused") }
        } catch (e: Exception) { disconnect(); "Cannot reach the phone: ${e.message}" }
    }

    fun set(lat: Double, lon: Double): String? = try {
        val r = call(JSONObject().put("cmd", "set").put("lat", lat).put("lon", lon))
        if (r.optBoolean("ok")) null else r.optString("error", "the phone refused")
    } catch (e: Exception) { "Connection lost: ${e.message}" }

    fun stop(): String? = try {
        val r = call(JSONObject().put("cmd", "stop")); if (r.optBoolean("ok")) null else r.optString("error", "error")
    } catch (e: Exception) { "Connection lost: ${e.message}" }
}

/** Finds and runs `adb` (Android platform-tools) for USB mode. */
object Adb {
    fun find(): String? {
        val home = System.getProperty("user.home")
        val cands = listOf(
            "/opt/homebrew/bin/adb", "/usr/local/bin/adb", "$home/Library/Android/sdk/platform-tools/adb",
            "$home/Android/Sdk/platform-tools/adb", "C:\\Users\\${System.getProperty("user.name")}\\AppData\\Local\\Android\\Sdk\\platform-tools\\adb.exe"
        )
        cands.firstOrNull { File(it).canExecute() }?.let { return it }
        return try { run(listOf("/usr/bin/which", "adb")).trim().takeIf { it.startsWith("/") } } catch (_: Exception) { null }
    }

    fun run(cmd: List<String>): String {
        val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        if (!p.waitFor(10, TimeUnit.SECONDS)) p.destroyForcibly()
        return out
    }

    /** serial -> state ("device", "unauthorized", ...) */
    fun devices(adb: String): List<Pair<String, String>> =
        run(listOf(adb, "devices")).lines().drop(1).mapNotNull {
            val t = it.trim().split(Regex("\\s+")); if (t.size >= 2) t[0] to t[1] else null
        }

    fun forward(adb: String, serial: String, port: Int): String? {
        val out = run(listOf(adb, "-s", serial, "forward", "tcp:$port", "tcp:$port"))
        return if (out.contains("error", true)) out.trim() else null
    }
}
