package dev.fakegeo.desktop

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.res.useResource
import androidx.compose.ui.res.loadImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import dev.fakegeo.app.*
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.awt.FileDialog
import java.awt.Frame
import java.io.File
import java.net.URLEncoder

private val Accent = Color(0xFF2F6BFF)
private val Bg = Color(0xFFF1F3F7)
private val Ink = Color(0xFF1D2433)
private val Muted = Color(0xFF6B7280)

enum class Screen { Welcome, Mode, Device, Connect, Select, Setup, Map }

fun main() = application {
    val icon = remember { runCatching { useResource("icon.png", ::loadImageBitmap) }.getOrNull()?.let { BitmapPainter(it) } }
    Window(onCloseRequest = ::exitApplication, title = "FakeGeo", icon = icon, state = rememberWindowState(width = 1100.dp, height = 740.dp)) {
        MaterialTheme(colorScheme = lightColorScheme(primary = Accent, background = Bg, surface = Color.White)) { App() }
    }
}

@Composable
fun App() {
    var screen by remember { mutableStateOf(Screen.Welcome) }
    var device by remember { mutableStateOf<MuxDevice?>(null) }
    val map = remember { MapState(25.2048, 55.2708, 11) }
    Surface(Modifier.fillMaxSize(), color = Bg) {
        when (screen) {
            Screen.Welcome -> Welcome { screen = Screen.Mode }
            Screen.Mode -> ModeScreen(onBack = { screen = Screen.Welcome }) { screen = Screen.Device }
            Screen.Device -> DeviceType(onBack = { screen = Screen.Mode }) { screen = Screen.Connect }
            Screen.Connect -> Connect(onBack = { screen = Screen.Device }) { device = it; screen = Screen.Select }
            Screen.Select -> SelectDevice(device, onBack = { screen = Screen.Device }) { device = it; screen = Screen.Setup }
            Screen.Setup -> Setup(device!!, onBack = { screen = Screen.Select }) { screen = Screen.Map }
            Screen.Map -> MapScreen(device!!, map, onBack = { screen = Screen.Setup })
        }
    }
}

// ------------------------------------------------------------------ shared pieces

@Composable
private fun Page(title: String, onBack: (() -> Unit)?, bottom: @Composable RowScope.() -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(28.dp)) {
        Column(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink, textAlign = TextAlign.Center)
            Spacer(Modifier.height(24.dp))
            content()
        }
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (onBack != null) OutlinedButton(onClick = onBack) { Text("Back") }
            Spacer(Modifier.weight(1f))
            bottom()
        }
    }
}

@Composable
private fun Card(title: String, lines: List<String>, selected: Boolean, enabled: Boolean = true, badge: String? = null, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier.width(300.dp).height(210.dp).clip(shape)
            .border(BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Accent else Color(0xFFD7DCE5)), shape)
            .background(if (selected) Color(0xFFEFF4FF) else Color.White)
            .clickable(enabled = enabled, onClick = onClick).padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)).background(if (enabled) Accent else Color(0xFFB8BECB)), contentAlignment = Alignment.Center) {
            Text(title.take(1), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = if (enabled) Ink else Muted)
        if (badge != null) Text(badge, color = Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        for (l in lines) Text(l, color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun Next(text: String = "Next", enabled: Boolean = true, onClick: () -> Unit) =
    Button(onClick = onClick, enabled = enabled) { Text(text) }

// ------------------------------------------------------------------ 1. welcome

@Composable
private fun Welcome(onStart: () -> Unit) {
    var aware by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf(false) }
    Page("Best Location Changer for iPhone — Explore Anywhere!", null, bottom = { Next("Start", aware, onStart) }) {
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Card("General Mode", listOf("Change your iPhone's location", "over a USB cable from this Mac."), selected = true) {}
            Card("Android", listOf("Use the FakeGeo Android app", "(no computer needed)."), selected = false, enabled = false, badge = "Not here") {}
        }
        Spacer(Modifier.weight(1f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(aware, { aware = it })
            Text("I am aware of the ", color = Ink)
            Text("disclaimer", color = Accent, modifier = Modifier.clickable { dialog = true })
        }
    }
    if (dialog) AlertDialog(
        onDismissRequest = { dialog = false },
        confirmButton = { TextButton({ dialog = false }) { Text("OK") } },
        title = { Text("Disclaimer") },
        text = {
            Text(
                "Use this only on your own device and for your own privacy or testing. Some apps and games forbid " +
                "location changes and may restrict your account. This tool does not change your IP, language, SIM or " +
                "anything else besides the GPS position. You are responsible for how you use it."
            )
        }
    )
}

// ------------------------------------------------------------------ 2. mode

@Composable
private fun ModeScreen(onBack: () -> Unit, onNext: () -> Unit) {
    Page("Please select location simulation mode", onBack, bottom = { Next(onClick = onNext) }) {
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Card("USB Mode", listOf("Connect the iPhone with a cable.", "Stable, works for every app.", "iOS 17 and newer."), selected = true, badge = "Recommended") {}
            Card("Wi-Fi Mode", listOf("Wireless connection.", "Coming later."), selected = false, enabled = false, badge = "Soon") {}
        }
    }
}

// ------------------------------------------------------------------ 3. device type

@Composable
private fun DeviceType(onBack: () -> Unit, onNext: () -> Unit) {
    Page("Select the type of device to be operated", onBack, bottom = { Next(onClick = onNext) }) {
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Card("iOS", listOf("iPhone / iPad"), selected = true) {}
            Card("Android", listOf("Use the FakeGeo Android app."), selected = false, enabled = false, badge = "Soon") {}
        }
    }
}

// ------------------------------------------------------------------ 4. connect (waits for a cable)

@Composable
private fun Connect(onBack: () -> Unit, onFound: (MuxDevice) -> Unit) {
    var problem by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            val err = UsbMux.available()
            problem = err
            if (err == null) {
                val d = try { UsbMux.listDevices() } catch (_: Exception) { emptyList() }
                if (d.isNotEmpty()) { onFound(d.first()); return@LaunchedEffect }
            }
            delay(1500)
        }
    }
    Page("Please connect your iPhone to this Mac", onBack) {
        Row(horizontalArrangement = Arrangement.spacedBy(48.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(120.dp).height(230.dp).clip(RoundedCornerShape(22.dp)).border(3.dp, Color(0xFF9AA3B2), RoundedCornerShape(22.dp)).background(Color(0xFF1B1F2A)))
            Column(Modifier.widthIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Note:", fontWeight = FontWeight.Bold)
                Text("1. Make sure your iPhone is unlocked.")
                Text("2. Use a data cable (not a charge-only one).")
                Text("3. Tap \"Trust This Computer\" on the iPhone if asked.")
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Text("Waiting for an iPhone…", color = Muted)
                }
                problem?.let { Text(it, color = Color(0xFFC62828)) }
            }
        }
    }
}

// ------------------------------------------------------------------ 5. select device

@Composable
private fun SelectDevice(first: MuxDevice?, onBack: () -> Unit, onNext: (MuxDevice) -> Unit) {
    var list by remember { mutableStateOf(listOfNotNull(first)) }
    var sel by remember { mutableStateOf(first) }
    LaunchedEffect(Unit) { while (true) { try { list = UsbMux.listDevices() } catch (_: Exception) {}; delay(2000) } }
    Page("Please select the device to connect", onBack, bottom = { Next(enabled = sel != null && list.any { it.id == sel!!.id }) { onNext(sel!!) } }) {
        Column(Modifier.width(520.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (list.isEmpty()) Text("No device found. Reconnect the cable.", color = Muted)
            for (d in list) Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).border(1.dp, if (sel?.id == d.id) Accent else Color(0xFFD7DCE5), RoundedCornerShape(10.dp))
                    .clickable { sel = d }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(sel?.id == d.id, { sel = d })
                Column { Text("iPhone (USB)", fontWeight = FontWeight.SemiBold); Text(d.serial, color = Muted, fontSize = 12.sp) }
            }
        }
    }
}

// ------------------------------------------------------------------ 6. setup (trust, developer mode, disk image)

@Composable
private fun Setup(dev: MuxDevice, onBack: () -> Unit, onDone: () -> Unit) {
    var busy by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf("Step 1 is needed only the first time with this iPhone.\nIf you already did all three steps in the Android app, you can skip to the map.") }
    val clip = LocalClipboardManager.current
    DisposableEffect(Unit) {
        MockState.sink = { line -> synchronized(MockState) { report = (if (report == "Working…") "" else report) + line + "\n" } }
        onDispose { MockState.sink = null }
    }
    fun run(block: () -> String) {
        if (busy) return
        busy = true; report = "Working…"
        Thread {
            try { block() } catch (e: Throwable) { report += "ERROR: $e\n" }
            busy = false
        }.start()
    }
    Page("Prepare the iPhone", onBack, bottom = {
        TextButton(onClick = { clip.setText(AnnotatedString(report)) }) { Text("Copy log") }
        TextButton(onClick = { IosPairing.forget(); report = "Saved pairing deleted." }) { Text("Forget pairing") }
        Next("Continue to the map", !busy, onDone)
    }) {
        Column(Modifier.widthIn(max = 760.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(enabled = !busy, onClick = { run { IosPairing.pairAndTest(dev.id) } }) { Text("1 · Pair (tap Trust)") }
                Button(enabled = !busy, onClick = { run { IosPairing.pairAndTest(dev.id, enableDevMode = true) } }) { Text("2 · Enable Developer Mode") }
                Button(enabled = !busy, onClick = {
                    val fd = FileDialog(null as Frame?, "Select Image.dmg, BuildManifest.plist and the trustcache file", FileDialog.LOAD)
                    fd.isMultipleMode = true; fd.isVisible = true
                    val files = fd.files?.toList().orEmpty()
                    if (files.isNotEmpty()) run { IosPairing.pairAndTest(dev.id, ddiFiles = files) }
                }) { Text("3 · Mount disk image") }
            }
            Text(
                "Step 2: after it runs, turn on Settings › Privacy & Security › Developer Mode on the iPhone and let it restart. " +
                    "Step 3: pick the 3 files from the DeveloperDiskImage repo (PersonalizedImages/Xcode_iOS_DDI_Personalized); needs internet.",
                color = Muted, fontSize = 12.sp
            )
            Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF111827)).padding(12.dp)) {
                SelectionContainer {
                    Text(report, color = Color(0xFFD1D5DB), fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.verticalScroll(rememberScrollState()))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ 7. map

private fun geocode(q: String): List<Triple<String, Double, Double>> {
    val m = Regex("""^\s*(-?\d+(?:\.\d+)?)\s*[,; ]\s*(-?\d+(?:\.\d+)?)\s*$""").find(q)
    if (m != null) return listOf(Triple(q.trim(), m.groupValues[1].toDouble(), m.groupValues[2].toDouble()))
    val c = java.net.URL("https://photon.komoot.io/api/?limit=6&lang=en&q=" + URLEncoder.encode(q, "UTF-8")).openConnection()
    c.setRequestProperty("User-Agent", "FakeGeoDesktop/1.0"); c.connectTimeout = 8000; c.readTimeout = 8000
    val arr = JSONObject(c.getInputStream().use { String(it.readBytes()) }).getJSONArray("features")
    return (0 until arr.length()).map {
        val f = arr.getJSONObject(it); val p = f.getJSONObject("properties")
        val xy = f.getJSONObject("geometry").getJSONArray("coordinates")
        val name = listOfNotNull(p.optString("name").ifBlank { null }, p.optString("city").ifBlank { null }, p.optString("country").ifBlank { null }).distinct().joinToString(", ")
        Triple(name, xy.getDouble(1), xy.getDouble(0))
    }
}

@Composable
private fun MapScreen(dev: MuxDevice, map: MapState, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Triple<String, Double, Double>>>(emptyList()) }
    var searchErr by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    var updates by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { status = IosState.status; running = IosState.running; updates = IosState.updates; delay(500) } }

    fun search() {
        searchErr = null
        Thread { try { results = geocode(query); if (results.isEmpty()) searchErr = "Nothing found" } catch (e: Exception) { searchErr = "Search failed: ${e.message}" } }.start()
    }
    fun teleport() {
        val p = map.pin ?: return
        IosFeed.set(p.lat, p.lon); IosFeed.active = true; map.active = p
        IosSession.start(dev.id) { map.active = null }
    }

    Box(Modifier.fillMaxSize()) {
        MapView(map, Modifier.fillMaxSize()) { }
        // search + results
        Column(Modifier.align(Alignment.TopStart).padding(16.dp).width(380.dp)) {
            Row(Modifier.clip(RoundedCornerShape(12.dp)).background(Color.White).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("‹") }
                OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Search a place or lat, lon") })
                Spacer(Modifier.width(6.dp)); Button(onClick = ::search, enabled = query.isNotBlank()) { Text("Go") }
            }
            if (results.isNotEmpty() || searchErr != null) Column(Modifier.padding(top = 6.dp).clip(RoundedCornerShape(12.dp)).background(Color.White)) {
                searchErr?.let { Text(it, Modifier.padding(12.dp), color = Color(0xFFC62828)) }
                for ((n, la, lo) in results) Text(n, Modifier.fillMaxWidth().clickable { map.flyTo(la, lo); map.pin = LatLon(la, lo); results = emptyList() }.padding(12.dp), maxLines = 2)
            }
        }
        // action card
        Column(
            Modifier.align(Alignment.TopEnd).padding(16.dp).width(300.dp).clip(RoundedCornerShape(14.dp)).background(Color.White).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val p = map.pin
            Text(if (p == null) "Click the map to drop a pin" else "%.6f, %.6f".format(java.util.Locale.US, p.lat, p.lon), fontWeight = FontWeight.SemiBold)
            Button(onClick = ::teleport, enabled = p != null, modifier = Modifier.fillMaxWidth()) { Text(if (running) "Move here" else "Teleport") }
            if (running) Button(
                onClick = { IosSession.stop() }, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD93025))
            ) { Text("Stop (back to real location)") }
            if (status.isNotBlank()) Text(status + if (updates > 0) "  ·  updates: $updates" else "", color = Muted, fontSize = 12.sp)
        }
    }
}
