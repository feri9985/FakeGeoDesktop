package dev.fakegeo.desktop

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.loadImageBitmap
import androidx.compose.ui.res.useResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import dev.fakegeo.app.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.awt.FileDialog
import java.awt.Frame
import java.net.URLEncoder

private val Accent = Color(0xFF2F6BFF)
private val Teal = Color(0xFF06B6D4)
private val Ink = Color(0xFF1D2433)
private val Muted = Color(0xFF6B7280)
private val Danger = Color(0xFFD93025)

enum class Screen { Welcome, Mode, Device, Connect, Select, Setup, AndroidConnect, Map }

sealed class Target {
    data class Ios(val dev: MuxDevice) : Target()
    object Android : Target()
}

fun main() = application {
    val icon = remember { runCatching { useResource("icon.png", ::loadImageBitmap) }.getOrNull()?.let { BitmapPainter(it) } }
    Window(onCloseRequest = ::exitApplication, title = "FakeGeo", icon = icon, state = rememberWindowState(width = 1120.dp, height = 760.dp)) {
        MaterialTheme(colorScheme = lightColorScheme(primary = Accent, background = Color(0xFFEFF3FB), surface = Color.White)) { App() }
    }
}

@Composable
fun App() {
    var screen by remember { mutableStateOf(Screen.Welcome) }
    var wifi by remember { mutableStateOf(false) }
    var android by remember { mutableStateOf(false) }
    var device by remember { mutableStateOf<MuxDevice?>(null) }
    var target by remember { mutableStateOf<Target?>(null) }
    val map = remember { MapState(25.2048, 55.2708, 11) }
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFFE6EEFF), Color(0xFFF3ECFF), Color(0xFFE5F6FB))))) {
        when (screen) {
            Screen.Welcome -> Welcome { screen = Screen.Mode }
            Screen.Mode -> ModeScreen(wifi, { wifi = it }, onBack = { screen = Screen.Welcome }) { screen = Screen.Device }
            Screen.Device -> DeviceType(android, { android = it }, onBack = { screen = Screen.Mode }) { a -> android = a; screen = if (a) Screen.AndroidConnect else Screen.Connect }
            Screen.Connect -> Connect(wifi, onBack = { screen = Screen.Device }, onUsb = { wifi = false }) { l -> device = l.first(); screen = if (l.size == 1) Screen.Setup else Screen.Select }
            Screen.Select -> SelectDevice(device, wifi, onBack = { screen = Screen.Device }) { device = it; screen = Screen.Setup }
            Screen.Setup -> Setup(device!!, onBack = { screen = Screen.Device }) { target = Target.Ios(device!!); screen = Screen.Map }
            Screen.AndroidConnect -> AndroidConnect(wifi, onBack = { screen = Screen.Device }) { target = Target.Android; screen = Screen.Map }
            Screen.Map -> MapScreen(target!!, map, onBack = { screen = if (target is Target.Android) Screen.AndroidConnect else Screen.Setup })
        }
    }
}

// ------------------------------------------------------------------ building blocks

@Composable
private fun res(name: String): ImageBitmap? = remember(name) { runCatching { useResource(if (name.endsWith(".png")) name else "$name.png", ::loadImageBitmap) }.getOrNull() }

@Composable
private fun Pill(text: String, enabled: Boolean = true, primary: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.height(46.dp).alpha(if (enabled) 1f else 0.45f)
            .then(if (primary) Modifier.shadow(if (enabled) 8.dp else 0.dp, shape, ambientColor = Accent, spotColor = Accent) else Modifier)
            .clip(shape)
            .then(if (primary) Modifier.background(Brush.horizontalGradient(listOf(Accent, Teal))) else Modifier.background(Color.White).border(1.dp, Color(0xFFD0D6E2), shape))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 28.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (primary) Color.White else Ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp) }
}

@Composable
private fun Page(step: Int, title: AnnotatedString, onBack: (() -> Unit)?, bottom: @Composable RowScope.() -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 36.dp, vertical = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            res("icon.png")?.let { Image(it, null, Modifier.size(38.dp)) }
            Spacer(Modifier.width(10.dp))
            Text("FakeGeo", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Ink)
            Spacer(Modifier.weight(1f))
            if (step > 0) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (i in 1..6) Box(Modifier.height(6.dp).width(if (i == step) 28.dp else 10.dp).clip(CircleShape).background(if (i <= step) Accent else Color(0xFFCBD3E4)))
            }
        }
        Spacer(Modifier.height(16.dp))
        Column(
            Modifier.weight(1f).fillMaxWidth().shadow(18.dp, RoundedCornerShape(24.dp), ambientColor = Color(0x33203A8A), spotColor = Color(0x33203A8A))
                .clip(RoundedCornerShape(24.dp)).background(Color.White.copy(alpha = 0.92f)).padding(horizontal = 36.dp, vertical = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink, textAlign = TextAlign.Center)
            Spacer(Modifier.height(22.dp))
            content()
        }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (onBack != null) Pill("‹  Back", primary = false, onClick = onBack)
            Spacer(Modifier.weight(1f))
            bottom()
        }
    }
}

private fun plain(s: String) = AnnotatedString(s)

@Composable
private fun ModeCard(title: String, lines: List<String>, image: String, selected: Boolean, enabled: Boolean = true, badge: String? = null, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.width(320.dp).alpha(if (enabled) 1f else 0.5f)
            .shadow(if (selected) 16.dp else 6.dp, shape, ambientColor = Accent, spotColor = Accent)
            .clip(shape).background(Color.White)
            .border(if (selected) 3.dp else 1.dp, if (selected) Accent else Color(0xFFDDE2EE), shape)
            .clickable(enabled = enabled, onClick = onClick)
    ) {
        Box(Modifier.fillMaxWidth().height(190.dp)) {
            res(image)?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
            if (badge != null) Text(
                badge, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopStart).padding(12.dp).clip(RoundedCornerShape(50)).background(Accent).padding(horizontal = 10.dp, vertical = 4.dp)
            )
            if (selected) Box(Modifier.align(Alignment.TopEnd).padding(12.dp).size(26.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
                Text("✓", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Ink, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            for (l in lines) Text(l, color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

// ------------------------------------------------------------------ 1. welcome

@Composable
private fun Welcome(onStart: () -> Unit) {
    var aware by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf(false) }
    val title = buildAnnotatedString {
        append("The Best Location Changer for iPhone & Android\n")
        withStyle(SpanStyle(color = Accent)) { append("Explore anywhere!") }
    }
    Page(0, title, null, bottom = { Pill("Start  ›", aware, onClick = onStart) }) {
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            ModeCard("iPhone / iPad", listOf("USB cable or Wi-Fi", "iOS 17 and newer"), "card_ios", selected = false, onClick = {})
            ModeCard("Android", listOf("USB (adb) or Wi-Fi", "with the FakeGeo Android app"), "card_android", selected = false, onClick = {})
        }
        Spacer(Modifier.weight(1f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(aware, { aware = it })
            Text("I am aware of the ", color = Ink)
            Text("disclaimer", color = Accent, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { dialog = true })
        }
    }
    if (dialog) AlertDialog(
        onDismissRequest = { dialog = false },
        confirmButton = { TextButton({ dialog = false }) { Text("OK") } },
        title = { Text("Disclaimer") },
        text = {
            Text(
                "Use this only on your own device and for your own privacy or testing. Some apps and games forbid " +
                    "location changes and may restrict your account. This tool changes only the GPS position, nothing else. " +
                    "You are responsible for how you use it."
            )
        }
    )
}

// ------------------------------------------------------------------ 2. mode / 3. device type

@Composable
private fun ModeScreen(wifi: Boolean, setWifi: (Boolean) -> Unit, onBack: () -> Unit, onNext: () -> Unit) {
    Page(1, plain("Please select the connection mode"), onBack, bottom = { Pill("Next  ›", onClick = onNext) }) {
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            ModeCard("USB Mode", listOf("Connect with a cable.", "Most stable, works every time."), "card_usb", !wifi, badge = "Recommended") { setWifi(false); onNext() }
            ModeCard("Wi-Fi Mode", listOf("No cable after the first setup.", "Phone and Mac on the same Wi-Fi."), "card_wifi", wifi, badge = "New") { setWifi(true); onNext() }
        }
    }
}

@Composable
private fun DeviceType(android: Boolean, setAndroid: (Boolean) -> Unit, onBack: () -> Unit, onNext: (Boolean) -> Unit) {
    Page(2, plain("Select the type of device to be operated"), onBack, bottom = { Pill("Next  ›", onClick = { onNext(android) }) }) {
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            ModeCard("iOS", listOf("iPhone / iPad"), "card_ios", !android) { setAndroid(false); onNext(false) }
            ModeCard("Android", listOf("Needs the FakeGeo Android app"), "card_android", android) { setAndroid(true); onNext(true) }
        }
    }
}

// ------------------------------------------------------------------ 4. connect iPhone

@Composable
private fun Connect(wifi: Boolean, onBack: () -> Unit, onUsb: () -> Unit, onFound: (List<MuxDevice>) -> Unit) {
    var problem by remember { mutableStateOf<String?>(null) }
    var wifiMsg by remember { mutableStateOf("") }
    var wifiBusy by remember { mutableStateOf(false) }
    var seen by remember { mutableStateOf("") }
    fun enableWifi() {
        if (wifiBusy) return
        wifiBusy = true; wifiMsg = "Working… tap Trust on the iPhone if it asks."
        Thread {
            wifiMsg = try {
                val usb = UsbMux.listDevices().firstOrNull { it.connection != "Network" }
                if (usb == null) "Connect the iPhone with the cable first, unlock it, then press the button again."
                else IosPairing.pairAndTest(usb.id, wifiOn = true).trim().lines().takeLast(5).joinToString("\n")
            } catch (e: Exception) { "Error: ${e.message}" }
            wifiBusy = false
        }.start()
    }
    LaunchedEffect(wifi) {
        while (true) {
            val err = UsbMux.available()
            problem = err
            if (err == null) {
                val all = try { UsbMux.listDevices() } catch (_: Exception) { emptyList() }
                seen = "macOS sees: ${all.count { it.connection != "Network" }} iPhone on USB, ${all.count { it.connection == "Network" }} on Wi-Fi"
                val d = all.filter { (it.connection == "Network") == wifi }
                if (d.isNotEmpty()) { onFound(d); return@LaunchedEffect }
            }
            delay(1500)
        }
    }
    Page(3, plain(if (wifi) "Looking for your iPhone on Wi-Fi" else "Please connect your iPhone to this Mac"), onBack) {
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(40.dp), verticalAlignment = Alignment.CenterVertically) {
            res("connect")?.let { Image(it, null, Modifier.width(400.dp).clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.FillWidth) }
            Column(Modifier.widthIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                if (!wifi) {
                    Text("Note", fontWeight = FontWeight.Bold, color = Ink)
                    Text("1.  Unlock the iPhone.")
                    Text("2.  Use a data cable (not charge-only).")
                    Text("3.  Tap “Trust This Computer” if asked.")
                } else {
                    Text("One-time setup", fontWeight = FontWeight.Bold, color = Ink)
                    Text("1.  Connect the iPhone with the cable and unlock it.")
                    Text("2.  Press the blue button below. Tap Trust on the iPhone if it asks.")
                    Text("3.  Unplug the cable. The iPhone and the Mac must be on the same Wi-Fi, with the iPhone awake.")
                    Pill("Turn on Wi-Fi for this iPhone", !wifiBusy, onClick = ::enableWifi)
                    if (wifiMsg.isNotBlank()) Text(wifiMsg, color = Muted, fontSize = 12.sp)
                    Pill("Use USB instead", primary = false, onClick = onUsb)
                }
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Text("Waiting for an iPhone…", color = Muted)
                }
                if (seen.isNotBlank()) Text(seen, color = Muted, fontSize = 12.sp)
                problem?.let { Text(it, color = Danger) }
            }
        }
    }
}

// ------------------------------------------------------------------ 5. select

@Composable
private fun SelectDevice(first: MuxDevice?, wifi: Boolean, onBack: () -> Unit, onNext: (MuxDevice) -> Unit) {
    var list by remember { mutableStateOf(listOfNotNull(first)) }
    var sel by remember { mutableStateOf(first) }
    LaunchedEffect(wifi) { while (true) { try { list = UsbMux.listDevices().filter { (it.connection == "Network") == wifi } } catch (_: Exception) {}; delay(2000) } }
    Page(4, plain("Please select the device to connect"), onBack, bottom = { Pill("Next  ›", sel != null && list.any { it.id == sel!!.id }) { onNext(sel!!) } }) {
        Column(Modifier.width(560.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (list.isEmpty()) Text("No device found. Reconnect the iPhone.", color = Muted)
            for (d in list) {
                val on = sel?.id == d.id
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (on) Color(0xFFEFF4FF) else Color.White)
                        .border(if (on) 2.dp else 1.dp, if (on) Accent else Color(0xFFDDE2EE), RoundedCornerShape(14.dp))
                        .clickable { sel = d }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    res("card_ios")?.let { Image(it, null, Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop) }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (d.connection == "Network") "iPhone (Wi-Fi)" else "iPhone (USB)", fontWeight = FontWeight.SemiBold, color = Ink)
                        Text(d.serial, color = Muted, fontSize = 12.sp)
                    }
                    RadioButton(on, { sel = d })
                }
            }
        }
    }
}

// ------------------------------------------------------------------ 6. setup

@Composable
private fun Setup(dev: MuxDevice, onBack: () -> Unit, onDone: () -> Unit) {
    var busy by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf("Pairing… tap Trust on the iPhone if it asks.\nIf you already did all three steps before, just continue to the map.") }
    val clip = LocalClipboardManager.current
    DisposableEffect(Unit) {
        MockState.sink = { line -> synchronized(MockState) { report = (if (report == "Working…") "" else report) + line + "\n" } }
        onDispose { MockState.sink = null }
    }
    fun run(block: () -> String) {
        if (busy) return
        busy = true; report = "Working…"
        Thread { try { block() } catch (e: Throwable) { report += "ERROR: $e\n" }; busy = false }.start()
    }
    LaunchedEffect(Unit) { run { IosPairing.pairAndTest(dev.id) } }
    Page(5, plain("Prepare the iPhone"), onBack, bottom = {
        Pill("Copy log", primary = false) { clip.setText(AnnotatedString(report)) }
        Pill("Forget pairing", primary = false) { IosPairing.forget(); report = "Saved pairing deleted." }
        Pill("Continue to the map  ›", !busy, onClick = onDone)
    }) {
        Column(Modifier.widthIn(max = 800.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("1 · Pair (tap Trust)", !busy) { run { IosPairing.pairAndTest(dev.id) } }
                Pill("2 · Enable Developer Mode", !busy) { run { IosPairing.pairAndTest(dev.id, enableDevMode = true) } }
                Pill("3 · Mount disk image", !busy) {
                    val fd = FileDialog(null as Frame?, "Select Image.dmg, BuildManifest.plist and the trustcache file", FileDialog.LOAD)
                    fd.isMultipleMode = true; fd.isVisible = true
                    val files = fd.files?.toList().orEmpty()
                    if (files.isNotEmpty()) run { IosPairing.pairAndTest(dev.id, ddiFiles = files) }
                }
            }
            Text(
                "Step 2: then turn on Settings › Privacy & Security › Developer Mode on the iPhone and let it restart. " +
                    "Step 3: pick the 3 files from the DeveloperDiskImage repo (PersonalizedImages/Xcode_iOS_DDI_Personalized); needs internet.",
                color = Muted, fontSize = 12.sp
            )
            Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF111827)).padding(14.dp)) {
                SelectionContainer {
                    Text(report, color = Color(0xFFD1D5DB), fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.verticalScroll(rememberScrollState()))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ 7. Android connect

@Composable
private fun AndroidConnect(wifi: Boolean, onBack: () -> Unit, onDone: () -> Unit) {
    var host by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var adb by remember { mutableStateOf<String?>(null) }
    var devs by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var searchTick by remember { mutableStateOf(0) }
    LaunchedEffect(wifi, searchTick) {
        if (wifi) {
            searching = true
            val ip = withContext(Dispatchers.IO) { AndroidRemote.discover() }
            if (ip != null) host = ip
            searching = false
        }
    }
    LaunchedEffect(wifi) {
        if (!wifi) while (true) {
            val a = Adb.find(); adb = a
            devs = if (a != null) try { Adb.devices(a) } catch (_: Exception) { emptyList() } else emptyList()
            delay(2000)
        }
    }
    fun go(block: () -> String?) {
        if (busy) return; busy = true; msg = "Connecting…"
        Thread { val e = try { block() } catch (e: Exception) { e.message ?: "error" }; busy = false; if (e == null) onDone() else msg = e }.start()
    }
    Page(4, plain(if (wifi) "Connect to your Android phone over Wi-Fi" else "Connect your Android phone with USB"), onBack) {
        Row(horizontalArrangement = Arrangement.spacedBy(40.dp), verticalAlignment = Alignment.CenterVertically) {
            res("card_android")?.let { Image(it, null, Modifier.width(360.dp).clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.FillWidth) }
            Column(Modifier.widthIn(max = 460.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("On the phone", fontWeight = FontWeight.Bold, color = Ink)
                Text("1.  Install the FakeGeo app with remote control and open it.")
                Text("2.  The app shows a PIN at the top when it starts. Type only the PIN here.")
                if (wifi) {
                    Text("3.  Phone and Mac must be on the same Wi-Fi.")
                    if (searching) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Text("Looking for the phone…", color = Muted)
                    } else Pill("Search again", primary = false) { searchTick++ }
                    OutlinedTextField(host, { host = it }, singleLine = true, label = { Text("Phone IP (filled in automatically)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(pin, { pin = it }, singleLine = true, label = { Text("PIN") }, modifier = Modifier.fillMaxWidth())
                    Pill("Connect", host.isNotBlank() && pin.isNotBlank() && !busy) { go { AndroidRemote.connect(host.trim(), AndroidRemote.PORT, pin.trim()) } }
                } else {
                    Text("3.  Enable USB debugging and allow this Mac.")
                    when {
                        adb == null -> Text("adb not found. In Terminal run:  brew install --cask android-platform-tools", color = Danger, fontSize = 13.sp)
                        devs.isEmpty() -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Text("Waiting for an Android phone…", color = Muted)
                        }
                        else -> for ((serial, st) in devs) {
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).border(1.dp, Color(0xFFDDE2EE), RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(serial, fontWeight = FontWeight.SemiBold); Text(if (st == "device") "ready" else st, color = Muted, fontSize = 12.sp) }
                                Pill("Connect", st == "device" && !busy) {
                                    go { Adb.forward(adb!!, serial, AndroidRemote.PORT) ?: AndroidRemote.connect("127.0.0.1", AndroidRemote.PORT, "") }
                                }
                            }
                        }
                    }
                }
                if (msg.isNotBlank()) Text(msg, color = if (msg == "Connecting…") Muted else Danger, fontSize = 13.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ 8. map

private fun geocode(q: String): List<Triple<String, Double, Double>> {
    val m = Regex("""^\s*(-?\d+(?:\.\d+)?)\s*[,; ]\s*(-?\d+(?:\.\d+)?)\s*$""").find(q)
    if (m != null) return listOf(Triple(q.trim(), m.groupValues[1].toDouble(), m.groupValues[2].toDouble()))
    val c = java.net.URL("https://photon.komoot.io/api/?limit=6&lang=en&q=" + URLEncoder.encode(q, "UTF-8")).openConnection()
    c.setRequestProperty("User-Agent", "FakeGeoDesktop/1.0"); c.connectTimeout = 8000; c.readTimeout = 8000
    val arr = JSONObject(c.getInputStream().use { String(it.readBytes()) }).getJSONArray("features")
    return (0 until arr.length()).map {
        val f = arr.getJSONObject(it); val p = f.getJSONObject("properties")
        val xy = f.getJSONObject("geometry").getJSONArray("coordinates")
        val name = listOfNotNull(p.optString("name").ifBlank { null }, p.optString("city").ifBlank { null }, p.optString("country").ifBlank { null }).distinct().joinToString(", ")
        Triple(name, xy.getDouble(1), xy.getDouble(0))
    }
}

@Composable
private fun MapScreen(target: Target, map: MapState, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Triple<String, Double, Double>>>(emptyList()) }
    var searchErr by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    var updates by remember { mutableStateOf(0) }
    var androidMsg by remember { mutableStateOf("") }
    var androidRunning by remember { mutableStateOf(false) }
    val isAndroid = target is Target.Android
    LaunchedEffect(Unit) { while (true) { status = IosState.status; running = IosState.running; updates = IosState.updates; delay(500) } }

    fun search() {
        searchErr = null
        Thread { try { results = geocode(query); if (results.isEmpty()) searchErr = "Nothing found" } catch (e: Exception) { searchErr = "Search failed: ${e.message}" } }.start()
    }
    fun teleport() {
        val p = map.pin ?: return
        when (target) {
            is Target.Ios -> { IosFeed.set(p.lat, p.lon); IosFeed.active = true; map.active = p; IosSession.start(target.dev.id) { map.active = null } }
            Target.Android -> Thread {
                androidMsg = "Sending…"
                val e = AndroidRemote.set(p.lat, p.lon)
                if (e == null) { androidRunning = true; map.active = p; androidMsg = "The Android phone is at %.5f, %.5f".format(java.util.Locale.US, p.lat, p.lon) }
                else androidMsg = e
            }.start()
        }
    }
    fun stopAll() {
        if (isAndroid) Thread { val e = AndroidRemote.stop(); androidRunning = false; map.active = null; androidMsg = e ?: "Stopped: the phone is back on its real location." }.start()
        else IosSession.stop()
    }
    val live = if (isAndroid) androidRunning else running
    val statusText = if (isAndroid) androidMsg else status + if (updates > 0) "  ·  updates: $updates" else ""

    Box(Modifier.fillMaxSize()) {
        MapView(map, Modifier.fillMaxSize()) { }
        Column(Modifier.align(Alignment.TopStart).padding(18.dp).width(400.dp)) {
            Row(
                Modifier.shadow(10.dp, RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onBack) { Text("‹", fontSize = 22.sp) }
                OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Search a place or lat, lon") })
                Spacer(Modifier.width(8.dp)); Pill("Go", query.isNotBlank(), onClick = ::search)
            }
            if (results.isNotEmpty() || searchErr != null) Column(Modifier.padding(top = 8.dp).shadow(10.dp, RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp)).background(Color.White)) {
                searchErr?.let { Text(it, Modifier.padding(14.dp), color = Danger) }
                for ((n, la, lo) in results) Text(n, Modifier.fillMaxWidth().clickable { map.flyTo(la, lo); map.pin = LatLon(la, lo); results = emptyList() }.padding(14.dp), maxLines = 2)
            }
        }
        Column(
            Modifier.align(Alignment.TopEnd).padding(18.dp).width(310.dp).shadow(14.dp, RoundedCornerShape(20.dp)).clip(RoundedCornerShape(20.dp)).background(Color.White).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val p = map.pin
            Text(if (isAndroid) "Android phone" else "iPhone", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(if (p == null) "Click the map to drop a pin" else "%.6f, %.6f".format(java.util.Locale.US, p.lat, p.lon), fontWeight = FontWeight.Bold, color = Ink)
            Pill(if (live) "Move here" else "Teleport", p != null, onClick = ::teleport)
            if (live) Box(
                Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(50)).background(Danger).clickable { stopAll() },
                contentAlignment = Alignment.Center
            ) { Text("Stop · back to real location", color = Color.White, fontWeight = FontWeight.SemiBold) }
            if (statusText.isNotBlank()) Text(statusText, color = Muted, fontSize = 12.sp)
        }
    }
}
