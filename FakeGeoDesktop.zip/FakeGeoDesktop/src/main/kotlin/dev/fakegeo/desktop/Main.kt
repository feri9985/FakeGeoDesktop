package dev.fakegeo.desktop

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.loadImageBitmap
import androidx.compose.ui.res.useResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import dev.fakegeo.app.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.awt.FileDialog
import java.awt.Frame
import java.net.URLEncoder

private val Accent = Color(0xFF2F6BFF)
private val Teal = Color(0xFF06B6D4)
private val Ink = Color(0xFF1D2433)
private val Muted = Color(0xFF6B7280)
private val Danger = Color(0xFFD93025)
private val Green = Color(0xFF16A34A)
private val Amber = Color(0xFFF59E0B)
private val Grey = Color(0xFF9CA3AF)

enum class Screen { Welcome, Mode, Device, Connect, Select, Setup, AndroidConnect, Map }

sealed class Target {
    data class Ios(val devs: List<MuxDevice>) : Target()
    object Android : Target()
}

fun main() = application {
    val icon = remember { runCatching { useResource("icon.png", ::loadImageBitmap) }.getOrNull()?.let { BitmapPainter(it) } }
    Window(onCloseRequest = ::exitApplication, title = "FakeGeo", icon = icon, state = rememberWindowState(width = 1120.dp, height = 760.dp)) {
        MaterialTheme(colorScheme = lightColorScheme(primary = Accent, background = Color(0xFFEFF3FB), surface = Color.White)) { App() }
    }
}

@Composable
fun App() {
    var screen by remember { mutableStateOf(Screen.Welcome) }
    var wifi by remember { mutableStateOf(false) }
    var android by remember { mutableStateOf(false) }
    var devices by remember { mutableStateOf<List<MuxDevice>>(emptyList()) }
    var target by remember { mutableStateOf<Target?>(null) }
    val map = remember { MapState(25.2048, 55.2708, 11) }
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFFE6EEFF), Color(0xFFF3ECFF), Color(0xFFE5F6FB))))) {
        when (screen) {
            Screen.Welcome -> Welcome { screen = Screen.Mode }
            Screen.Mode -> ModeScreen(wifi, { wifi = it }, onBack = { screen = Screen.Welcome }) { screen = Screen.Device }
            Screen.Device -> DeviceType(android, { android = it }, onBack = { screen = Screen.Mode }) { a -> android = a; screen = if (a) Screen.AndroidConnect else Screen.Connect }
            Screen.Connect -> Connect(wifi, onBack = { screen = Screen.Device }, onUsb = { wifi = false }) { l -> devices = l; screen = if (l.size == 1 && l[0].id < 0) Screen.Setup else Screen.Select }
            Screen.Select -> SelectDevice(devices, wifi, onBack = { screen = Screen.Device }) { devices = it; screen = Screen.Setup }
            Screen.Setup -> Setup(devices, onBack = { screen = Screen.Device }) { target = Target.Ios(devices); screen = Screen.Map }
            Screen.AndroidConnect -> AndroidConnect(wifi, onBack = { screen = Screen.Device }) { target = Target.Android; screen = Screen.Map }
            Screen.Map -> MapScreen(target!!, map, onBack = { screen = if (target is Target.Android) Screen.AndroidConnect else Screen.Setup })
        }
    }
}

// ------------------------------------------------------------------ building blocks

@Composable
private fun res(name: String): ImageBitmap? = remember(name) { runCatching { useResource(if (name.endsWith(".png")) name else "$name.png", ::loadImageBitmap) }.getOrNull() }

@Composable
private fun Pill(text: String, enabled: Boolean = true, primary: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.height(46.dp).alpha(if (enabled) 1f else 0.45f)
            .then(if (primary) Modifier.shadow(if (enabled) 8.dp else 0.dp, shape, ambientColor = Accent, spotColor = Accent) else Modifier)
            .clip(shape)
            .then(if (primary) Modifier.background(Brush.horizontalGradient(listOf(Accent, Teal))) else Modifier.background(Color.White).border(1.dp, Color(0xFFD0D6E2), shape))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 28.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (primary) Color.White else Ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp) }
}

@Composable
private fun Page(step: Int, title: AnnotatedString, onBack: (() -> Unit)?, bottom: @Composable RowScope.() -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 36.dp, vertical = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            res("icon.png")?.let { Image(it, null, Modifier.size(38.dp)) }
            Spacer(Modifier.width(10.dp))
            Text("FakeGeo", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Ink)
            Spacer(Modifier.weight(1f))
            if (step > 0) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (i in 1..6) Box(Modifier.height(6.dp).width(if (i == step) 28.dp else 10.dp).clip(CircleShape).background(if (i <= step) Accent else Color(0xFFCBD3E4)))
            }
        }
        Spacer(Modifier.height(16.dp))
        Column(
            Modifier.weight(1f).fillMaxWidth().shadow(18.dp, RoundedCornerShape(24.dp), ambientColor = Color(0x33203A8A), spotColor = Color(0x33203A8A))
                .clip(RoundedCornerShape(24.dp)).background(Color.White.copy(alpha = 0.92f)).padding(horizontal = 36.dp, vertical = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink, textAlign = TextAlign.Center)
            Spacer(Modifier.height(22.dp))
            content()
        }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (onBack != null) Pill("‹  Back", primary = false, onClick = onBack)
            Spacer(Modifier.weight(1f))
            bottom()
        }
    }
}

private fun plain(s: String) = AnnotatedString(s)

@Composable
private fun ModeCard(title: String, lines: List<String>, image: String, selected: Boolean, enabled: Boolean = true, badge: String? = null, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.width(320.dp).alpha(if (enabled) 1f else 0.5f)
            .shadow(if (selected) 16.dp else 6.dp, shape, ambientColor = Accent, spotColor = Accent)
            .clip(shape).background(Color.White)
            .border(if (selected) 3.dp else 1.dp, if (selected) Accent else Color(0xFFDDE2EE), shape)
            .clickable(enabled = enabled, onClick = onClick)
    ) {
        Box(Modifier.fillMaxWidth().height(190.dp)) {
            res(image)?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
            if (badge != null) Text(
                badge, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopStart).padding(12.dp).clip(RoundedCornerShape(50)).background(Accent).padding(horizontal = 10.dp, vertical = 4.dp)
            )
            if (selected) Box(Modifier.align(Alignment.TopEnd).padding(12.dp).size(26.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
                Text("✓", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Ink, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            for (l in lines) Text(l, color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

// ------------------------------------------------------------------ 1. welcome

@Composable
private fun Welcome(onStart: () -> Unit) {
    var aware by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf(false) }
    val title = buildAnnotatedString {
        append("The Best Location Changer for iPhone & Android\n")
        withStyle(SpanStyle(color = Accent)) { append("Explore anywhere!") }
    }
    Page(0, title, null, bottom = { Pill("Start  ›", aware, onClick = onStart) }) {
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            ModeCard("iPhone / iPad", listOf("USB cable or Wi-Fi", "iOS 17 and newer"), "card_ios", selected = false, onClick = {})
            ModeCard("Android", listOf("USB (adb) or Wi-Fi", "with the FakeGeo Android app"), "card_android", selected = false, onClick = {})
        }
        Spacer(Modifier.weight(1f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(aware, { aware = it })
            Text("I am aware of the ", color = Ink)
            Text("disclaimer", color = Accent, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { dialog = true })
        }
    }
    if (dialog) AlertDialog(
        onDismissRequest = { dialog = false },
        confirmButton = { TextButton({ dialog = false }) { Text("OK") } },
        title = { Text("Disclaimer") },
        text = {
            Text(
                "Use this only on your own device and for your own privacy or testing. Some apps and games forbid " +
                    "location changes and may restrict your account. This tool changes only the GPS position, nothing else. " +
                    "You are responsible for how you use it."
            )
        }
    )
}

// ------------------------------------------------------------------ 2. mode / 3. device type

@Composable
private fun ModeScreen(wifi: Boolean, setWifi: (Boolean) -> Unit, onBack: () -> Unit, onNext: () -> Unit) {
    Page(1, plain("Please select the connection mode"), onBack, bottom = { Pill("Next  ›", onClick = onNext) }) {
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            ModeCard("USB Mode", listOf("Connect with a cable.", "Most stable, works every time."), "card_usb", !wifi, badge = "Recommended") { setWifi(false); onNext() }
            ModeCard("Wi-Fi Mode", listOf("No cable after the first setup.", "Phone and Mac on the same Wi-Fi."), "card_wifi", wifi, badge = "New") { setWifi(true); onNext() }
        }
    }
}

@Composable
private fun DeviceType(android: Boolean, setAndroid: (Boolean) -> Unit, onBack: () -> Unit, onNext: (Boolean) -> Unit) {
    Page(2, plain("Select the type of device to be operated"), onBack, bottom = { Pill("Next  ›", onClick = { onNext(android) }) }) {
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            ModeCard("iOS", listOf("iPhone / iPad"), "card_ios", !android) { setAndroid(false); onNext(false) }
            ModeCard("Android", listOf("Needs the FakeGeo Android app"), "card_android", android) { setAndroid(true); onNext(true) }
        }
    }
}

// ------------------------------------------------------------------ 4. connect iPhone

@Composable
private fun Connect(wifi: Boolean, onBack: () -> Unit, onUsb: () -> Unit, onFound: (List<MuxDevice>) -> Unit) {
    var problem by remember { mutableStateOf<String?>(null) }
    var wifiMsg by remember { mutableStateOf("") }
    var wifiBusy by remember { mutableStateOf(false) }
    var seen by remember { mutableStateOf("") }
    var wifiInfo by remember { mutableStateOf("") }
    var rpMsg by remember { mutableStateOf("") }
    var rpBusy by remember { mutableStateOf(false) }
    var pyBin by remember { mutableStateOf<String?>(null) }
    var pyChecked by remember { mutableStateOf(false) }
    LaunchedEffect(wifi) { if (wifi) { pyBin = withContext(Dispatchers.IO) { WifiTunnel.locate() }; pyChecked = true } }
    fun testRemotePairing() {
        if (rpBusy) return
        rpBusy = true; rpMsg = "Working…"
        Thread {
            val acc = ArrayList<String>()
            try { RemotePairing.discover { acc.add(it); rpMsg = acc.joinToString("\n") } }
            catch (e: Throwable) { acc.add("Error: $e"); rpMsg = acc.joinToString("\n") }
            rpBusy = false
        }.also { it.isDaemon = true }.start()
    }
    fun enableWifi() {
        if (wifiBusy) return
        wifiBusy = true; wifiMsg = "Working… tap Trust on the iPhone if it asks."
        Thread {
            wifiMsg = try {
                val usb = UsbMux.listDevices().firstOrNull { it.connection != "Network" }
                if (usb == null) "Connect the iPhone with the cable first, unlock it, then press the button again."
                else IosPairing.pairAndTest(usb.id, wifiOn = true).trim().lines().takeLast(5).joinToString("\n")
            } catch (e: Exception) { "Error: ${e.message}" }
            wifiBusy = false
        }.start()
    }
    LaunchedEffect(wifi) {
        var lastScan = 0L
        while (true) {
            val err = UsbMux.available()
            problem = err
            if (err == null) {
                val all = try { UsbMux.listDevices() } catch (_: Exception) { emptyList() }
                seen = "macOS sees: ${all.count { it.connection != "Network" }} iPhone on USB, ${all.count { it.connection == "Network" }} on Wi-Fi"
                var d = all.filter { (it.connection == "Network") == wifi }
                // the network scan is heavy (about 1000 addresses): at most every 20 seconds
                if (d.isEmpty() && wifi && System.currentTimeMillis() - lastScan > 20_000) {
                    lastScan = System.currentTimeMillis()
                    d = withContext(Dispatchers.IO) { WifiDiscovery.find { wifiInfo = it } }
                }
                if (d.isNotEmpty()) { onFound(d); return@LaunchedEffect }
            }
            delay(1500)
        }
    }
    Page(3, plain(if (wifi) "Looking for your iPhone on Wi-Fi" else "Please connect your iPhone to this Mac"), onBack) {
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(40.dp), verticalAlignment = Alignment.CenterVertically) {
            res("connect")?.let { Image(it, null, Modifier.width(400.dp).clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.FillWidth) }
            Column(Modifier.widthIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                if (!wifi) {
                    Text("Note", fontWeight = FontWeight.Bold, color = Ink)
                    Text("1.  Unlock the iPhone.")
                    Text("2.  Use a data cable (not charge-only).")
                    Text("3.  Tap “Trust This Computer” if asked.")
                } else {
                    Text("One-time setup", fontWeight = FontWeight.Bold, color = Ink)
                    Text("1.  Connect the iPhone with the cable and unlock it.")
                    Text("2.  Press the blue button below. Tap Trust on the iPhone if it asks.")
                    Text("3.  Unplug the cable. Keep the iPhone unlocked with the screen on, on the same Wi-Fi as the Mac.")
                    Pill("Turn on Wi-Fi for this iPhone", !wifiBusy, onClick = ::enableWifi)
                    if (wifiMsg.isNotBlank()) Text(wifiMsg, color = Muted, fontSize = 12.sp)
                    Text("4.  Wi-Fi mode finds the iPhone through its own tunnel, so you can continue even if no iPhone is listed below.")
                    Text(
                        when {
                            !pyChecked -> "Checking for pymobiledevice3…"
                            pyBin != null -> "pymobiledevice3: found ($pyBin)"
                            else -> "pymobiledevice3 NOT found. Install it once in Terminal:  pip3 install -U pymobiledevice3"
                        },
                        color = if (pyChecked && pyBin == null) Danger else Muted, fontSize = 12.sp
                    )
                    Pill("Continue with the Wi-Fi tunnel  ›", pyBin != null) { onFound(listOf(MuxDevice(-1, "", "Network", 0))) }
                    Pill("Use USB instead", primary = false, onClick = onUsb)
                    Pill("RemotePairing test (stage 1)", !rpBusy, primary = false, onClick = ::testRemotePairing)
                    if (rpMsg.isNotBlank()) SelectionContainer { Text(rpMsg, color = Muted, fontSize = 12.sp) }
                }
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Text("Waiting for an iPhone…", color = Muted)
                }
                if (seen.isNotBlank()) Text(seen, color = Muted, fontSize = 12.sp)
                if (wifi && wifiInfo.isNotBlank()) Text(wifiInfo, color = Muted, fontSize = 12.sp)
                problem?.let { Text(it, color = Danger) }
            }
        }
    }
}

// ------------------------------------------------------------------ 5. select

@Composable
private fun SelectDevice(first: List<MuxDevice>, wifi: Boolean, onBack: () -> Unit, onNext: (List<MuxDevice>) -> Unit) {
    fun keyOf(d: MuxDevice) = d.serial.ifEmpty { "id${d.id}" }
    var list by remember { mutableStateOf(first) }
    val sel = remember { mutableStateMapOf<String, Boolean>().also { m -> first.forEach { m[keyOf(it)] = true } } }
    val infos = remember { mutableStateMapOf<String, DevInfo>() }
    val tried = remember { HashMap<String, Long>() }
    LaunchedEffect(wifi) {
        while (true) {
            try {
                val l = withContext(Dispatchers.IO) {
                    val cur = UsbMux.listDevices().filter { (it.connection == "Network") == wifi }
                    for (d in cur) {
                        val k = keyOf(d)
                        // ask each iPhone for its model once (again after 15 s if it did not answer)
                        if (infos[k] == null && System.currentTimeMillis() - (tried[k] ?: 0L) > 15_000) {
                            tried[k] = System.currentTimeMillis()
                            DeviceInfo.lookup(d)?.let { infos[k] = it }
                        }
                    }
                    cur
                }
                for (d in l) if (sel[keyOf(d)] == null) sel[keyOf(d)] = true     // a new iPhone is selected by default
                list = l
            } catch (_: Exception) {}
            delay(2000)
        }
    }
    val chosen = list.filter { sel[keyOf(it)] == true }
    Page(4, plain("Please select the device to connect"), onBack, bottom = { Pill("Next  ›", chosen.isNotEmpty()) { onNext(chosen) } }) {
        Column(Modifier.width(600.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("You can select several iPhones. All the selected ones follow the same location at the same time.", color = Muted, fontSize = 13.sp)
            if (list.isEmpty()) Text("No device found. Reconnect the iPhone.", color = Muted)
            for (d in list) {
                val k = keyOf(d)
                val on = sel[k] == true
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (on) Color(0xFFEFF4FF) else Color.White)
                        .border(if (on) 2.dp else 1.dp, if (on) Accent else Color(0xFFDDE2EE), RoundedCornerShape(14.dp))
                        .clickable { sel[k] = !on }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    res("card_ios")?.let { Image(it, null, Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop) }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(DeviceInfo.title(d, infos[k]), fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 17.sp)
                        Text(DeviceInfo.subtitle(d, infos[k]), color = Muted, fontSize = 12.sp)
                    }
                    Checkbox(on, { sel[k] = it })
                }
            }
        }
    }
}

// ------------------------------------------------------------------ 6. setup

@Composable
private fun Setup(devs: List<MuxDevice>, onBack: () -> Unit, onDone: () -> Unit) {
    var busy by remember { mutableStateOf(false) }
    var curIdx by remember { mutableStateOf(0) }
    val dev = devs[curIdx.coerceIn(0, devs.size - 1)]
    val usb = dev.connection != "Network"
    var report by remember(dev.serial) {
        mutableStateOf(
            if (usb) "Pairing… tap Trust on the iPhone if it asks.\nIf you already did all three steps before, just continue to the map."
            else "Wi-Fi mode: pairing, Developer Mode and the disk image are done ONCE with the cable (USB Mode). If you did that already, just continue to the map."
        )
    }
    val clip = LocalClipboardManager.current
    // usbmuxd gives the iPhone a new id every time it re-attaches (for example after the Developer Mode restart): find it again by serial
    fun curId(): Int = (try { UsbMux.listDevices().firstOrNull { it.serial == dev.serial && it.connection != "Network" }?.id } catch (_: Exception) { null }) ?: dev.id
    DisposableEffect(Unit) {
        MockState.sink = { line -> synchronized(MockState) { report = (if (report == "Working…") "" else report) + line + "\n" } }
        onDispose { MockState.sink = null }
    }
    fun run(block: () -> String) {
        if (busy) return
        busy = true; report = "Working…"
        Thread { try { block() } catch (e: Throwable) { report += "ERROR: $e\n" }; busy = false }.start()
    }
    LaunchedEffect(dev.serial) { if (usb) run { IosPairing.pairAndTest(curId()) } }
    Page(5, plain("Prepare the iPhone"), onBack, bottom = {
        Pill("Copy log", primary = false) { clip.setText(AnnotatedString(report)) }
        Pill("Forget pairing", primary = false) { IosPairing.forget(); report = "Saved pairing deleted." }
        Pill("Continue to the map  ›", !busy, onClick = onDone)
    }) {
        Column(Modifier.widthIn(max = 800.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (devs.size > 1) {
                Text("Set up each iPhone once (pairing, Developer Mode, disk image). Tap a name to switch:", color = Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for ((i, d) in devs.withIndex()) {
                        val on = i == curIdx
                        Text(
                            DeviceInfo.title(d, DeviceInfo.cached(d.serial)), color = if (on) Color.White else Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(if (on) Accent else Color(0xFFE8ECF6))
                                .clickable(enabled = !busy) { curIdx = i }.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("1 · Pair (tap Trust)", !busy && usb) { run { IosPairing.pairAndTest(curId()) } }
                Pill("2 · Enable Developer Mode", !busy && usb) { run { IosPairing.pairAndTest(curId(), enableDevMode = true) } }
                Pill("RemotePairing test", !busy, primary = false) {
                    run { RemotePairing.discover { MockState.log("RP: $it") }; "" }
                }
                Pill("3 · Mount disk image", !busy && usb) {
                    val fd = FileDialog(null as Frame?, "Select Image.dmg, BuildManifest.plist and the trustcache file", FileDialog.LOAD)
                    fd.isMultipleMode = true; fd.isVisible = true
                    val files = fd.files?.toList().orEmpty()
                    if (files.isNotEmpty()) run { IosPairing.pairAndTest(curId(), ddiFiles = files) }
                }
            }
            Text(
                "Step 2: then turn on Settings › Privacy & Security › Developer Mode on the iPhone and let it restart. " +
                    "Step 3: pick the 3 files from the DeveloperDiskImage repo (PersonalizedImages/Xcode_iOS_DDI_Personalized); needs internet.",
                color = Muted, fontSize = 12.sp
            )
            Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF111827)).padding(14.dp)) {
                SelectionContainer {
                    Text(report, color = Color(0xFFD1D5DB), fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.verticalScroll(rememberScrollState()))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ 7. Android connect

@Composable
private fun AndroidConnect(wifi: Boolean, onBack: () -> Unit, onDone: () -> Unit) {
    var msg by remember { mutableStateOf("") }
    var tick by remember { mutableStateOf(0) }                       // changes when a phone connects / disconnects: redraws the list
    var adb by remember { mutableStateOf<String?>(null) }
    var devs by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    val names = remember { mutableStateMapOf<String, String>() }     // adb serial -> "Samsung Galaxy S23"
    var phones by remember { mutableStateOf<List<String>>(emptyList()) }   // Wi-Fi: IPs of the phones found
    val pins = remember { mutableStateMapOf<String, String>() }
    val busyKeys = remember { mutableStateMapOf<String, Boolean>() }
    var manual by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var searchTick by remember { mutableStateOf(0) }
    var scanMsg by remember { mutableStateOf("") }
    val connectedKeys = run { tick; AndroidHub.links.filter { it.connected }.map { it.key }.toSet() }

    // Wi-Fi: keeps looking for phones (every 10 s) while this screen is open
    LaunchedEffect(wifi, searchTick) {
        if (wifi) while (true) {
            searching = true
            val l = withContext(Dispatchers.IO) { AndroidRemote.discoverAll { scanMsg = it } }
            searching = false
            phones = (phones + l).distinct()
            delay(10_000)
        }
    }
    // USB: the phones adb sees, with their model names
    LaunchedEffect(wifi) {
        if (!wifi) while (true) {
            val a = withContext(Dispatchers.IO) { Adb.find() }
            adb = a
            devs = if (a != null) withContext(Dispatchers.IO) { try { Adb.devices(a) } catch (_: Exception) { emptyList() } } else emptyList()
            if (a != null) for ((serial, st) in devs) {
                if (st == "device" && names[serial] == null) { val n = withContext(Dispatchers.IO) { Adb.title(a, serial) }; names[serial] = n }
            }
            delay(2000)
        }
    }
    fun connectUsb(a: String, serial: String) {
        if (busyKeys[serial] == true) return
        busyKeys[serial] = true; msg = ""
        Thread {
            val local = AndroidHub.portFor(serial)
            val e = Adb.forward(a, serial, local, AndroidRemote.PORT)
                ?: AndroidLink(serial, names[serial] ?: "Android phone", "127.0.0.1", local, "").also { AndroidHub.add(it) }.connect()
            if (e != null) { msg = "${names[serial] ?: serial}: $e"; AndroidHub.remove(serial) }
            busyKeys[serial] = false; tick++
        }.start()
    }
    fun connectWifi(ip: String) {
        if (busyKeys[ip] == true) return
        val pin = pins[ip].orEmpty().trim()
        busyKeys[ip] = true; msg = ""
        Thread {
            val l = AndroidLink(ip, "Android phone", ip, AndroidRemote.PORT, pin)
            AndroidHub.add(l)
            val e = l.connect()
            if (e != null) { msg = "$ip: $e"; AndroidHub.remove(ip) }
            busyKeys[ip] = false; tick++
        }.start()
    }
    fun disconnect(key: String) {
        Thread {
            val l = AndroidHub.find(key)
            if (l != null && l.sending) l.stop()          // give the phone its real location back first
            AndroidHub.remove(key); tick++
        }.start()
    }
    @Composable
    fun PhoneRow(key: String, title: String, sub: String, content: @Composable RowScope.() -> Unit) {
        val on = key in connectedKeys
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).border(1.dp, if (on) Green else Color(0xFFDDE2EE), RoundedCornerShape(12.dp)).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(if (on) Green else Grey))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = Ink)
                Text(sub + if (on) "  ·  connected" else "", color = if (on) Green else Muted, fontSize = 12.sp)
            }
            content()
        }
    }
    Page(4, plain(if (wifi) "Connect your Android phones over Wi-Fi" else "Connect your Android phones with USB"), onBack,
        bottom = { Pill("Continue  ›", connectedKeys.isNotEmpty(), onClick = onDone) }) {
        Row(horizontalArrangement = Arrangement.spacedBy(40.dp), verticalAlignment = Alignment.CenterVertically) {
            res("card_android")?.let { Image(it, null, Modifier.width(300.dp).clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.FillWidth) }
            Column(Modifier.widthIn(max = 540.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("On each phone", fontWeight = FontWeight.Bold, color = Ink)
                Text("1.  Install the FakeGeo app with remote control and open it.")
                if (wifi) {
                    Text("2.  Type the PIN that the app shows at the top, next to that phone.")
                    Text("3.  Phones and Mac must be on the same Wi-Fi. You can connect several phones: all of them get the same location.")
                    if (searching) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Text("Looking for phones…", color = Muted)
                    } else Pill("Search again", primary = false) { searchTick++ }
                    if (scanMsg.isNotBlank() && phones.isEmpty()) Text(scanMsg, color = Muted, fontSize = 12.sp)
                    for (ip in phones) {
                        PhoneRow(ip, AndroidHub.find(ip)?.label ?: "Android phone", ip) {
                            if (ip !in connectedKeys) {
                                OutlinedTextField(pins[ip].orEmpty(), { pins[ip] = it }, singleLine = true, label = { Text("PIN") }, modifier = Modifier.width(110.dp))
                                Spacer(Modifier.width(8.dp))
                            }
                            if (ip in connectedKeys) Pill("Disconnect", primary = false) { disconnect(ip) }
                            else Pill("Connect", busyKeys[ip] != true && pins[ip].orEmpty().isNotBlank()) { connectWifi(ip) }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(manual, { manual = it }, singleLine = true, label = { Text("Add a phone by IP") }, modifier = Modifier.weight(1f))
                        Pill("Add", manual.isNotBlank(), primary = false) { phones = (phones + manual.trim()).distinct(); manual = "" }
                    }
                } else {
                    Text("2.  Enable USB debugging and allow this Mac.")
                    Text("3.  You can plug in several phones: all of them get the same location.")
                    when {
                        adb == null -> Text("adb not found. In Terminal run:  brew install --cask android-platform-tools", color = Danger, fontSize = 13.sp)
                        devs.isEmpty() -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Text("Waiting for Android phones…", color = Muted)
                        }
                        else -> for ((serial, st) in devs) {
                            PhoneRow(serial, names[serial] ?: "Android phone", (if (st == "device") "ready" else st) + "  ·  " + serial) {
                                if (serial in connectedKeys) Pill("Disconnect", primary = false) { disconnect(serial) }
                                else Pill("Connect", st == "device" && busyKeys[serial] != true) { connectUsb(adb!!, serial) }
                            }
                        }
                    }
                }
                if (msg.isNotBlank()) Text(msg, color = Danger, fontSize = 13.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ 8. map

private fun geocode(q: String): List<Triple<String, Double, Double>> {
    val m = Regex("""^\s*(-?\d+(?:\.\d+)?)\s*[,; ]\s*(-?\d+(?:\.\d+)?)\s*$""").find(q)
    if (m != null) return listOf(Triple(q.trim(), m.groupValues[1].toDouble(), m.groupValues[2].toDouble()))
    val c = java.net.URL("https://photon.komoot.io/api/?limit=6&lang=en&q=" + URLEncoder.encode(q, "UTF-8")).openConnection()
    c.setRequestProperty("User-Agent", "FakeGeoDesktop/1.0"); c.connectTimeout = 8000; c.readTimeout = 8000
    val arr = JSONObject(c.getInputStream().use { String(it.readBytes()) }).getJSONArray("features")
    return (0 until arr.length()).map {
        val f = arr.getJSONObject(it); val p = f.getJSONObject("properties")
        val xy = f.getJSONObject("geometry").getJSONArray("coordinates")
        val name = listOfNotNull(p.optString("name").ifBlank { null }, p.optString("city").ifBlank { null }, p.optString("country").ifBlank { null }).distinct().joinToString(", ")
        Triple(name, xy.getDouble(1), xy.getDouble(0))
    }
}

/** One line of the device list on the map screen. state: 0 = off, 1 = connecting, 2 = connected, 3 = problem. */
private class DevRow(val key: String, val title: String, val sub: String, val state: Int, val msg: String, val on: Boolean)

@Composable
private fun DeviceLine(row: DevRow, onToggle: (Boolean) -> Unit) {
    val dot = when (row.state) { 2 -> Green; 1 -> Amber; 3 -> Danger; else -> Grey }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).border(1.dp, if (row.state == 2) Green else Color(0xFFE3E7F0), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(dot))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(row.title, fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 14.sp)
            Text(row.sub, color = Muted, fontSize = 11.sp)
            if (row.msg.isNotBlank()) Text(row.msg, color = if (row.state == 3) Danger else Muted, fontSize = 11.sp, maxLines = 3)
        }
        Checkbox(row.on, onToggle)
    }
}

@Composable
private fun MapScreen(target: Target, map: MapState, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Triple<String, Double, Double>>>(emptyList()) }
    var searchErr by remember { mutableStateOf<String?>(null) }
    var rows by remember { mutableStateOf<List<DevRow>>(emptyList()) }
    val enabled = remember { mutableStateMapOf<String, Boolean>() }
    var showLog by remember { mutableStateOf(false) }
    var logText by remember { mutableStateOf("") }
    val logScroll = rememberScrollState()
    val panelScroll = rememberScrollState()
    val clip = LocalClipboardManager.current
    val isAndroid = target is Target.Android
    val iosDevs = (target as? Target.Ios)?.devs ?: emptyList()
    fun keyOf(d: MuxDevice) = d.serial.ifEmpty { "id${d.id}" }
    fun labelOf(d: MuxDevice) = DeviceInfo.title(d, DeviceInfo.cached(d.serial))

    fun buildRows(): List<DevRow> =
        if (isAndroid) AndroidHub.links.map { l ->
            val st = when {
                l.connected -> 2
                l.message.startsWith("Cannot") || l.message.startsWith("Connection lost") -> 3
                else -> 0
            }
            DevRow(l.key, l.label, if (l.host == "127.0.0.1") "USB  ·  ${l.key}" else "Wi-Fi  ·  ${l.host}", st, if (l.sending || st == 3) l.message else "", enabled[l.key] != false)
        } else iosDevs.map { d ->
            val k = keyOf(d)
            val st = IosSessions.of(k, labelOf(d)).state
            val state = when {
                st.running && st.live -> 2
                st.running -> 1
                st.lastError.isNotBlank() -> 3
                else -> 0
            }
            DevRow(k, labelOf(d), DeviceInfo.subtitle(d, DeviceInfo.cached(d.serial)), state, if (state == 0) "" else st.status, enabled[k] != false)
        }

    LaunchedEffect(Unit) {
        while (true) {
            rows = buildRows()
            logText = if (showLog) FileLog.text() else ""
            if (!isAndroid && IosSessions.runningCount() == 0 && map.active != null) map.active = null
            delay(500)
        }
    }
    LaunchedEffect(logText) { if (showLog) logScroll.scrollTo(logScroll.maxValue) }

    fun search() {
        searchErr = null
        Thread { try { results = geocode(query); if (results.isEmpty()) searchErr = "Nothing found" } catch (e: Exception) { searchErr = "Search failed: ${e.message}" } }.start()
    }
    fun teleport() {
        val p = map.pin ?: return
        if (isAndroid) {
            val chosen = AndroidHub.links.filter { enabled[it.key] != false }
            if (chosen.isEmpty()) return
            map.active = p
            for (l in chosen) Thread { l.set(p.lat, p.lon) }.also { it.isDaemon = true }.start()
        } else {
            val chosen = iosDevs.filter { enabled[keyOf(it)] != false }
            if (chosen.isEmpty()) return
            IosFeed.set(p.lat, p.lon)          // every running session follows this position
            map.active = p
            val multi = chosen.size > 1
            val wifiSerials = chosen.filter { it.connection == "Network" }.map { it.serial }
            Thread {
                // one password prompt for all the Wi-Fi tunnels
                if (wifiSerials.isNotEmpty()) WifiTunnel.prepare(wifiSerials, multi)
                for (d in chosen) IosSessions.of(keyOf(d), labelOf(d)).start(d.id, d.connection == "Network", d.serial, multi)
            }.also { it.isDaemon = true }.start()
        }
    }
    fun stopAll() {
        if (isAndroid) Thread {
            for (l in AndroidHub.links) if (l.sending) l.stop()
            map.active = null
        }.also { it.isDaemon = true }.start()
        else IosSessions.stopAll()
    }
    val live = if (isAndroid) rows.any { it.state == 2 && AndroidHub.find(it.key)?.sending == true } else rows.any { it.state == 1 || it.state == 2 }
    val connectedCount = rows.count { it.state == 2 }

    Box(Modifier.fillMaxSize()) {
        MapView(map, Modifier.fillMaxSize()) { }
        Column(Modifier.align(Alignment.TopStart).padding(18.dp).width(400.dp)) {
            Row(
                Modifier.shadow(10.dp, RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onBack) { Text("‹", fontSize = 22.sp) }
                OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Search a place or lat, lon") })
                Spacer(Modifier.width(8.dp)); Pill("Go", query.isNotBlank(), onClick = ::search)
            }
            if (results.isNotEmpty() || searchErr != null) Column(Modifier.padding(top = 8.dp).shadow(10.dp, RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp)).background(Color.White)) {
                searchErr?.let { Text(it, Modifier.padding(14.dp), color = Danger) }
                for ((n, la, lo) in results) Text(n, Modifier.fillMaxWidth().clickable { map.flyTo(la, lo); map.pin = LatLon(la, lo); results = emptyList() }.padding(14.dp), maxLines = 2)
            }
        }
        Column(
            Modifier.align(Alignment.TopEnd).padding(18.dp).width(340.dp).heightIn(max = 700.dp)
                .shadow(14.dp, RoundedCornerShape(20.dp)).clip(RoundedCornerShape(20.dp)).background(Color.White)
                .verticalScroll(panelScroll).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val p = map.pin
            Text(if (isAndroid) "Android phones" else "iPhones", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            if (rows.isEmpty()) Text("No phone connected. Go back and connect one.", color = Muted, fontSize = 12.sp)
            for (r in rows) DeviceLine(r) { on ->
                enabled[r.key] = on
                if (!on) {
                    if (isAndroid) { val l = AndroidHub.find(r.key); if (l != null) Thread { l.stop() }.also { it.isDaemon = true }.start() }
                    else iosDevs.firstOrNull { keyOf(it) == r.key }?.let { IosSessions.of(r.key, labelOf(it)).stop() }
                } else if (live) teleport()          // switched on while the others are already moving: join them
            }
            if (rows.isNotEmpty()) Text("$connectedCount of ${rows.size} connected", color = Muted, fontSize = 12.sp)
            Text(if (p == null) "Click the map to drop a pin" else "%.6f, %.6f".format(java.util.Locale.US, p.lat, p.lon), fontWeight = FontWeight.Bold, color = Ink)
            Pill(if (live) "Move here" else "Teleport", p != null && rows.any { it.on }, onClick = ::teleport)
            if (live) Box(
                Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(50)).background(Danger).clickable { stopAll() },
                contentAlignment = Alignment.Center
            ) { Text("Stop · back to real location", color = Color.White, fontWeight = FontWeight.SemiBold) }
            Text(
                if (showLog) "Hide log ▲" else "Show log ▼", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { showLog = !showLog }
            )
            if (showLog) {
                Box(Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF111827)).padding(8.dp)) {
                    SelectionContainer {
                        Text(
                            logText, color = Color(0xFFD1D5DB), fontFamily = FontFamily.Monospace, fontSize = 10.sp,
                            modifier = Modifier.verticalScroll(logScroll)
                        )
                    }
                }
                Text("Copy log", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { clip.setText(AnnotatedString(FileLog.text())) })
                Text("Saved in: ${FileLog.file.path}", color = Muted, fontSize = 10.sp)
            }
        }
    }
}
